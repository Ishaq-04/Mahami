package com.ishaq.mahami;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HourlyAlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ALERT = "mahami_hourly_alert_v2";
    private static final String CHANNEL_QUIET = "mahami_hourly_quiet_v2";
    public static final int SUMMARY_NOTIF_ID = 1001;
    private static final int SEPARATE_BASE_ID = 5000;

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isSnooze = intent != null && intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_SNOOZE, false);
        if (!isSnooze) {
            AlarmScheduler.scheduleNextExactHour(context);
        }
        triggerAlarmOrNotification(context, false);
    }

    public static void triggerAlarmOrNotification(Context context, boolean isTest) {
        List<TaskItem> dueTasks = TaskStorage.getDueAlarmTasks(context);
        if (!isTest && dueTasks.isEmpty()) {
            cancelAllNotifications(context);
            return;
        }

        if (TaskStorage.isFullAlarmMode(context)) {
            try {
                Intent serviceIntent = new Intent(context, AlarmRingingService.class);
                serviceIntent.setAction(AlarmRingingService.ACTION_START);
                serviceIntent.putExtra(AlarmRingingService.EXTRA_IS_TEST, isTest);
                ContextCompat.startForegroundService(context, serviceIntent);
                return;
            } catch (Exception ignored) {
                // fallback to strong notification if OS restricts FGS
            }
        }

        postAlertNotification(context, isTest);
    }

    public static void postAlertNotification(Context context, boolean isTest) {
        if (!hasNotificationPermission(context)) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannels(nm);

        List<TaskItem> tasks = TaskStorage.getDueAlarmTasks(context);
        String nowStr = new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date());
        PendingIntent openPi = buildOpenAppIntent(context);

        if (TaskStorage.isSeparateNotifs(context) && !tasks.isEmpty()) {
            for (int i = 0; i < Math.min(tasks.size(), 10); i++) {
                TaskItem t = tasks.get(i);
                String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
                String title = "⏰ (" + nowStr + ") " + icon + " " + t.title;
                String body = "📂 " + t.category
                        + ((t.dueLabel != null && !t.dueLabel.isEmpty()) ? " • 🕒 " + t.dueLabel : "")
                        + ((t.notes != null && !t.notes.isEmpty()) ? "\n" + t.notes : "");

                NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ALERT)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_ALARM)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setContentIntent(openPi)
                        .setAutoCancel(false);

                nm.notify(SEPARATE_BASE_ID + i, b.build());
            }
        } else {
            buildAndPostSummary(context, nm, CHANNEL_ALERT, tasks, nowStr, isTest, true);
        }
    }

    public static void postQuietReminderSummary(Context context, boolean isTest) {
        if (!hasNotificationPermission(context)) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannels(nm);

        List<TaskItem> tasks = TaskStorage.getDueAlarmTasks(context);
        if (!isTest && tasks.isEmpty()) {
            cancelAllNotifications(context);
            return;
        }
        String nowStr = new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date());
        buildAndPostSummary(context, nm, CHANNEL_QUIET, tasks, nowStr, isTest, false);
    }

    private static void buildAndPostSummary(
            Context context,
            NotificationManager nm,
            String channelId,
            List<TaskItem> tasks,
            String nowStr,
            boolean isTest,
            boolean loud
    ) {
        String title;
        String summary;
        NotificationCompat.InboxStyle inbox = new NotificationCompat.InboxStyle();

        if (tasks.isEmpty()) {
            title = "⏰ تجربة التذكير الساعي (" + nowStr + ")";
            summary = "النظام نشط وسيذكّرك عند الدقيقة :00 من كل ساعة.";
            inbox.addLine(summary);
        } else {
            title = "⏰ تذكير رأس الساعة (" + nowStr + ") — " + tasks.size() + " مهام متبقية";
            summary = "افتح تطبيق مهامي لإنجاز مهامك وإسقاطها";
            for (int i = 0; i < tasks.size(); i++) {
                TaskItem t = tasks.get(i);
                String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
                String label = (t.dueLabel != null && !t.dueLabel.isEmpty()) ? " (" + t.dueLabel + ")" : "";
                inbox.addLine((i + 1) + ". " + icon + " " + t.title + " [" + t.category + "]" + label);
            }
        }
        inbox.setBigContentTitle(title);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(summary)
                .setStyle(inbox)
                .setPriority(loud ? NotificationCompat.PRIORITY_MAX : NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(false)
                .setContentIntent(buildOpenAppIntent(context));

        nm.notify(SUMMARY_NOTIF_ID, builder.build());
    }

    public static void cancelAllNotifications(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(SUMMARY_NOTIF_ID);
            for (int i = 0; i < 10; i++) {
                nm.cancel(SEPARATE_BASE_ID + i);
            }
        }
    }

    private static PendingIntent buildOpenAppIntent(Context context) {
        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(
                context, 3001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private static void ensureChannels(NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_ALERT) == null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ALERT,
                        "تنبيه رأس الساعة الصوتي",
                        NotificationManager.IMPORTANCE_HIGH
                );
                ch.setDescription("إشعار صوتي قوي عند رأس كل ساعة للمهام غير المنجزة");
                ch.enableVibration(true);
                ch.setVibrationPattern(new long[]{0, 700, 350, 700});
                ch.setBypassDnd(true);
                Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                ch.setSound(sound, attrs);
                nm.createNotificationChannel(ch);
            }

            if (nm.getNotificationChannel(CHANNEL_QUIET) == null) {
                NotificationChannel quiet = new NotificationChannel(
                        CHANNEL_QUIET,
                        "ملخص المهام المعلّقة",
                        NotificationManager.IMPORTANCE_LOW
                );
                quiet.setDescription("يبقي قائمة المهام ظاهرة في شريط الإشعارات بعد إسكات المنبه");
                quiet.setSound(null, null);
                nm.createNotificationChannel(quiet);
            }
        }
    }
}
