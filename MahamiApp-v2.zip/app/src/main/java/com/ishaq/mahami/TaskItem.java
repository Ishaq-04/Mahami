package com.ishaq.mahami;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TaskItem {
    public String id;
    public String title;
    public String category;
    public String priority;      // عالية | متوسطة | عادية
    public String dueDate;       // YYYY-MM-DD أو فارغ
    public String dueLabel;      // اليوم | غداً | الخميس... | أي وقت
    public String notes;         // خطوة تنفيذية مختصرة
    public int estimatedMinutes; // المدة التقديرية بالدقائق
    public boolean completed;
    public long createdAt;
    public long completedAt;
    public long snoozedUntil;    // تأجيل التذكير حتى هذا الطابع الزمني

    public TaskItem(
            String id,
            String title,
            String category,
            String priority,
            String dueDate,
            String dueLabel,
            String notes,
            int estimatedMinutes,
            boolean completed,
            long createdAt,
            long completedAt,
            long snoozedUntil
    ) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.priority = priority;
        this.dueDate = dueDate;
        this.dueLabel = dueLabel;
        this.notes = notes;
        this.estimatedMinutes = estimatedMinutes;
        this.completed = completed;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.snoozedUntil = snoozedUntil;
    }

    public boolean isSnoozedNow() {
        return snoozedUntil > System.currentTimeMillis();
    }

    public boolean isFutureScheduled() {
        if (dueDate == null || dueDate.trim().isEmpty()) return false;
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return dueDate.trim().compareTo(today) > 0;
    }

    public boolean isDueForAlarm(boolean includeFuture) {
        if (completed) return false;
        if (isSnoozedNow()) return false;
        if (!includeFuture && isFutureScheduled()) return false;
        return true;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("title", title);
        obj.put("category", category);
        obj.put("priority", priority);
        obj.put("dueDate", dueDate == null ? "" : dueDate);
        obj.put("dueLabel", dueLabel == null ? "" : dueLabel);
        obj.put("notes", notes == null ? "" : notes);
        obj.put("estimatedMinutes", estimatedMinutes);
        obj.put("completed", completed);
        obj.put("createdAt", createdAt);
        obj.put("completedAt", completedAt);
        obj.put("snoozedUntil", snoozedUntil);
        return obj;
    }

    public static TaskItem fromJson(JSONObject obj) {
        return new TaskItem(
                obj.optString("id", "t_" + System.currentTimeMillis()),
                obj.optString("title", ""),
                obj.optString("category", "عام"),
                obj.optString("priority", "متوسطة"),
                obj.optString("dueDate", ""),
                obj.optString("dueLabel", obj.optString("timeHint", "")),
                obj.optString("notes", ""),
                obj.optInt("estimatedMinutes", 0),
                obj.optBoolean("completed", false),
                obj.optLong("createdAt", System.currentTimeMillis()),
                obj.optLong("completedAt", 0L),
                obj.optLong("snoozedUntil", 0L)
        );
    }
}
