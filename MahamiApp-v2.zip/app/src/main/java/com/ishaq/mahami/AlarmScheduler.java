package com.ishaq.mahami;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmScheduler {

    public static final String EXTRA_IS_SNOOZE = "extra_is_snooze";
    private static final int REQ_HOURLY = 2001;
    private static final int REQ_SHOW_APP = 2002;
    private static final int REQ_SNOOZE = 2005;

    public static long getNextExactHourMillis() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, 1);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public static String getNextExactHourFormatted() {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", new Locale("ar"));
        return sdf.format(new Date(getNextExactHourMillis()));
    }

    public static void scheduleNextExactHour(Context context) {
        scheduleExact(context, getNextExactHourMillis(), REQ_HOURLY, false);
    }

    public static void scheduleSnoozeMinutes(Context context, int minutes) {
        long triggerAt = System.currentTimeMillis() + (minutes * 60L * 1000L);
        scheduleExact(context, triggerAt, REQ_SNOOZE, true);
    }

    private static void scheduleExact(Context context, long triggerAt, int requestCode, boolean isSnooze) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent receiverIntent = new Intent(context, HourlyAlarmReceiver.class);
        receiverIntent.putExtra(EXTRA_IS_SNOOZE, isSnooze);

        PendingIntent alarmPendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                receiverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openAppIntent = new Intent(context, MainActivity.class);
        PendingIntent showPendingIntent = PendingIntent.getActivity(
                context,
                REQ_SHOW_APP,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent);
                alarmManager.setAlarmClock(info, alarmPendingIntent);
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, alarmPendingIntent);
            }
        } else {
            AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent);
            alarmManager.setAlarmClock(info, alarmPendingIntent);
        }
    }
}
