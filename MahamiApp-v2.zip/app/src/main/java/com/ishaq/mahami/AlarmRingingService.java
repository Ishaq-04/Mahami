package com.ishaq.mahami;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlarmRingingService extends Service {

    public static final String ACTION_START = "com.ishaq.mahami.ACTION_START_ALARM";
    public static final String ACTION_STOP = "com.ishaq.mahami.ACTION_STOP_ALARM";
    public static final String ACTION_SNOOZE = "com.ishaq.mahami.ACTION_SNOOZE_ALARM";
    public static final String EXTRA_IS_TEST = "extra_is_test";

    private static final String CHANNEL_RINGING = "mahami_ringing_service_v2";
    private static final int RINGING_NOTIF_ID = 2026;
    private static final long AUTO_SILENCE_MS = 60_000L; // يتوقف الرنين تلقائياً بعد 60 ثانية ويبقى الإشعار ظاهراً

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isTestRun = false;

    private final Runnable autoStopRunnable = new Runnable() {
        @Override
        public void run() {
            stopAlarmAndKeepSummary();
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = (intent != null && intent.getAction() != null) ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            stopAlarmAndKeepSummary();
            return START_NOT_STICKY;
        }

        if (ACTION_SNOOZE.equals(action)) {
            AlarmScheduler.scheduleSnoozeMinutes(this, 10);
            stopAlarmAndKeepSummary();
            return START_NOT_STICKY;
        }

        isTestRun = intent != null && intent.getBooleanExtra(EXTRA_IS_TEST, false);
        startRingingSequence();
        return START_NOT_STICKY;
    }

    private void startRingingSequence() {
        ensureRingingChannel();
        Notification notification = buildRingingNotification();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(RINGING_NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(RINGING_NOTIF_ID, notification);
        }

        acquireWakeLock();
        startAlarmSound();
        startVibration();

        handler.removeCallbacks(autoStopRunnable);
        handler.postDelayed(autoStopRunnable, AUTO_SILENCE_MS);

        try {
            Intent activityIntent = new Intent(this, AlarmRingingActivity.class);
            activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            activityIntent.putExtra(EXTRA_IS_TEST, isTestRun);
            startActivity(activityIntent);
        } catch (Exception ignored) {
        }
    }

    private Notification buildRingingNotification() {
        List<TaskItem> tasks = TaskStorage.getDueAlarmTasks(this);
        String nowStr = new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date());
        String title = tasks.isEmpty()
                ? "⏰ تجربة منبه رأس الساعة (" + nowStr + ")"
                : "⏰ منبه رأس الساعة (" + nowStr + ") — " + tasks.size() + " مهام متبقية";

        String subtitle = tasks.isEmpty()
                ? "نظام الإيقاظ المستمر يعمل بنجاح"
                : "الأهم الآن: " + tasks.get(0).title;

        Intent fullScreenIntent = new Intent(this, AlarmRingingActivity.class);
        fullScreenIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        fullScreenIntent.putExtra(EXTRA_IS_TEST, isTestRun);
        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
                this, 4001, fullScreenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, AlarmRingingService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this, 4002, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent snoozeIntent = new Intent(this, AlarmRingingService.class);
        snoozeIntent.setAction(ACTION_SNOOZE);
        PendingIntent snoozePendingIntent = PendingIntent.getService(
                this, 4003, snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_RINGING)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(subtitle)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setFullScreenIntent(fullScreenPendingIntent, true)
                .setContentIntent(fullScreenPendingIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إسكات المنبه", stopPendingIntent)
                .addAction(android.R.drawable.ic_popup_reminder, "غفوة 10 د", snoozePendingIntent)
                .build();
    }

    private void ensureRingingChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_RINGING) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_RINGING,
                        "شاشة رنين منبه رأس الساعة",
                        NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("يُستخدم لعرض شاشة المنبه المستمر عند كل رأس ساعة");
                channel.setSound(null, null); // الصوت يُدار مباشرة عبر MediaPlayer لضمان التكرار المستمر
                channel.enableVibration(false);
                channel.setBypassDnd(true);
                channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void startAlarmSound() {
        stopAlarmSound();
        try {
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (alarmUri == null) alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mediaPlayer.setDataSource(this, alarmUri);
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception ignored) {
        }
    }

    private void stopAlarmSound() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
    }

    private void startVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vibrator = vm.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = new long[]{0, 900, 450, 900, 450};
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
            }
        } catch (Exception ignored) {
        }
    }

    private void stopVibration() {
        if (vibrator != null) {
            try {
                vibrator.cancel();
            } catch (Exception ignored) {
            }
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahami:HourlyAlarmLock");
                wakeLock.acquire(AUTO_SILENCE_MS + 5000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {
            }
        }
        wakeLock = null;
    }

    private void stopAlarmAndKeepSummary() {
        handler.removeCallbacks(autoStopRunnable);
        stopAlarmSound();
        stopVibration();
        releaseWakeLock();

        // إبقاء إشعار صامت بقائمة المهام بعد إسكات المنبه كي لا تُنسى
        HourlyAlarmReceiver.postQuietReminderSummary(this, isTestRun);

        Intent closeUi = new Intent(AlarmRingingActivity.ACTION_CLOSE_ALARM_UI);
        closeUi.setPackage(getPackageName());
        sendBroadcast(closeUi);

        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autoStopRunnable);
        stopAlarmSound();
        stopVibration();
        releaseWakeLock();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
