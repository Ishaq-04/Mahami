package com.ishaq.mahami;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlarmRingingActivity extends AppCompatActivity {

    public static final String ACTION_CLOSE_ALARM_UI = "com.ishaq.mahami.CLOSE_ALARM_UI";

    private final BroadcastReceiver closeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            );
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null) {
            km.requestDismissKeyguard(this, null);
        }

        IntentFilter filter = new IntentFilter(ACTION_CLOSE_ALARM_UI);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(closeReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(closeReceiver, filter);
        }

        buildAlarmScreen();
    }

    private void buildAlarmScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.parseColor("#071426"));
        root.setPadding(dp(20), dp(36), dp(20), dp(24));

        String nowStr = new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date());

        TextView tvClock = new TextView(this);
        tvClock.setText("⏰ " + nowStr);
        tvClock.setTextColor(Color.parseColor("#38BDF8"));
        tvClock.setTextSize(34);
        tvClock.setTypeface(null, Typeface.BOLD);
        tvClock.setGravity(Gravity.CENTER);

        TextView tvSubtitle = new TextView(this);
        tvSubtitle.setText("تذكير رأس الساعة — مهام بانتظار الإنجاز");
        tvSubtitle.setTextColor(Color.parseColor("#CBD5E1"));
        tvSubtitle.setTextSize(15);
        tvSubtitle.setGravity(Gravity.CENTER);
        tvSubtitle.setPadding(0, dp(6), 0, dp(18));

        root.addView(tvClock);
        root.addView(tvSubtitle);

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        scroll.setLayoutParams(scrollParams);

        LinearLayout listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);

        List<TaskItem> dueTasks = TaskStorage.getDueAlarmTasks(this);
        if (dueTasks.isEmpty()) {
            TextView tvTest = new TextView(this);
            tvTest.setText("هذه تجربة لشاشة منبه رأس الساعة.\nعند إضافة مهام، ستظهر هنا مرتبة بالأولوية عند الدقيقة :00 من كل ساعة.");
            tvTest.setTextColor(Color.WHITE);
            tvTest.setTextSize(16);
            tvTest.setGravity(Gravity.CENTER);
            tvTest.setPadding(dp(14), dp(20), dp(14), dp(20));
            listLayout.addView(tvTest);
        } else {
            for (int i = 0; i < dueTasks.size(); i++) {
                TaskItem t = dueTasks.get(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14), dp(12), dp(14), dp(12));

                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor("#112645"));
                bg.setCornerRadius(dp(12));
                int borderColor = "عالية".equals(t.priority) ? Color.parseColor("#EF4444")
                        : ("متوسطة".equals(t.priority) ? Color.parseColor("#F59E0B") : Color.parseColor("#22C55E"));
                bg.setStroke(dp(1), borderColor);
                card.setBackground(bg);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = dp(10);
                card.setLayoutParams(lp);

                String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
                TextView tvTask = new TextView(this);
                tvTask.setText((i + 1) + ". " + icon + " " + t.title);
                tvTask.setTextColor(Color.WHITE);
                tvTask.setTextSize(17);
                tvTask.setTypeface(null, Typeface.BOLD);

                String meta = "📂 " + t.category;
                if (t.dueLabel != null && !t.dueLabel.isEmpty()) meta += "  •  🕒 " + t.dueLabel;
                if (t.estimatedMinutes > 0) meta += "  •  ⏱ " + t.estimatedMinutes + " د";
                TextView tvMeta = new TextView(this);
                tvMeta.setText(meta);
                tvMeta.setTextColor(Color.parseColor("#94A3B8"));
                tvMeta.setTextSize(13);
                tvMeta.setPadding(0, dp(4), 0, 0);

                card.addView(tvTask);
                card.addView(tvMeta);
                listLayout.addView(card);
            }
        }
        scroll.addView(listLayout);
        root.addView(scroll);

        Button btnSilenceOpen = makeActionButton("🔕 إسكات المنبه وفتح المهام", "#15803D");
        btnSilenceOpen.setOnClickListener(v -> {
            sendServiceAction(AlarmRingingService.ACTION_STOP);
            Intent main = new Intent(this, MainActivity.class);
            main.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(main);
            finish();
        });

        Button btnSnooze = makeActionButton("⏳ غفوة 10 دقائق", "#D97706");
        btnSnooze.setOnClickListener(v -> {
            sendServiceAction(AlarmRingingService.ACTION_SNOOZE);
            finish();
        });

        Button btnSilenceOnly = makeActionButton("إسكات فقط (سيعاود التذكير الساعة القادمة)", "#334155");
        btnSilenceOnly.setOnClickListener(v -> {
            sendServiceAction(AlarmRingingService.ACTION_STOP);
            finish();
        });

        root.addView(btnSilenceOpen);
        root.addView(btnSnooze);
        root.addView(btnSilenceOnly);

        setContentView(root);
    }

    private Button makeActionButton(String text, String hexColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(15);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setAllCaps(false);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(dp(12));
        btn.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void sendServiceAction(String action) {
        Intent i = new Intent(this, AlarmRingingService.class);
        i.setAction(action);
        startService(i);
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(closeReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
