package com.ishaq.mahami;

import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {

    public interface Callback {
        void onSuccess(List<TaskItem> tasks);
        void onError(String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final String[] MODELS = new String[]{"gemini-2.5-flash", "gemini-2.0-flash"};

    public static void extractTasksFromText(final String apiKey, final String userText, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> tasks = callGeminiExtract(apiKey, userText, null);
                MAIN_HANDLER.post(() -> callback.onSuccess(tasks));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "خطأ غير معروف"));
            }
        });
    }

    public static void extractTasksFromAudio(final String apiKey, final File audioFile, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> tasks = callGeminiExtract(apiKey, null, audioFile);
                MAIN_HANDLER.post(() -> callback.onSuccess(tasks));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "خطأ في معالجة التسجيل الصوتي"));
            }
        });
    }

    public static void replanExistingTasks(final String apiKey, final List<TaskItem> currentTasks, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> replanned = callGeminiReplan(apiKey, currentTasks);
                MAIN_HANDLER.post(() -> callback.onSuccess(replanned));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "تعذر إعادة الترتيب"));
            }
        });
    }

    private static String getCurrentDateTimeContext() {
        Date now = new Date();
        String isoDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now);
        String time24 = new SimpleDateFormat("HH:mm", Locale.US).format(now);
        String dayName = new SimpleDateFormat("EEEE", new Locale("ar")).format(now);
        return "التاريخ الحالي: " + isoDate + " (" + dayName + ")، الساعة الآن: " + time24;
    }

    private static List<TaskItem> callGeminiExtract(String apiKey, String textInput, File audioFile) throws Exception {
        validateKey(apiKey);

        String prompt =
                "أنت مدير مهام شخصي محترف باللغة العربية. " + getCurrentDateTimeContext() + ".\n" +
                "المطلوب: استخرج كل المهام من مدخل المستخدم (سواء كان نصاً عشوائياً أو تسجيلاً صوتياً باللهجة العراقية أو الفصحى).\n" +
                "قواعد صارمة:\n" +
                "1. صغ عنوان المهمة (title) بأسلوب تنفيذي واضح ومباشر ومختصر.\n" +
                "2. اختر التصنيف (category) حصراً من: دراسة، بحث، عمل، شخصي، عام.\n" +
                "3. حدد الأولوية (priority) بدقة: عالية، متوسطة، عادية.\n" +
                "4. إذا ذكر المستخدم موعداً محدداً في المستقبل (مثل: غداً، باجر، الخميس، بعد يومين)، احسب تاريخه بدقة بصيغة YYYY-MM-DD في due_date، وضع وصفاً قصيراً في due_label (مثل: غداً - الجمعة). وإذا كانت المهمة لليوم أو بدون وقت محدد، اجعل due_date فارغاً واجعل due_label اليوم أو فارغاً.\n" +
                "5. أضف ملاحظة تنفيذية قصيرة جداً وعملية في notes (إن كانت مفيدة لتسريع الإنجاز)، وقدّر المدة بالدقائق في estimated_minutes (رقم صحيح مثل 15 أو 30 أو 60).\n" +
                "أعد JSON فقط بهذا الشكل الدقيق:\n" +
                "{\"tasks\": [{\"title\": \"...\", \"category\": \"دراسة\", \"priority\": \"عالية\", \"due_date\": \"\", \"due_label\": \"اليوم\", \"notes\": \"...\", \"estimated_minutes\": 30}]}";

        JSONArray parts = new JSONArray();
        JSONObject promptPart = new JSONObject();
        promptPart.put("text", prompt);
        parts.put(promptPart);

        if (textInput != null) {
            JSONObject userPart = new JSONObject();
            userPart.put("text", "مدخل المستخدم:\n" + textInput);
            parts.put(userPart);
        } else if (audioFile != null && audioFile.exists()) {
            byte[] audioBytes = readFileBytes(audioFile);
            String base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP);
            JSONObject inlineData = new JSONObject();
            inlineData.put("mimeType", "audio/mp4");
            inlineData.put("data", base64Audio);
            JSONObject audioPart = new JSONObject();
            audioPart.put("inlineData", inlineData);
            parts.put(audioPart);
        }

        String rawJson = executeWithFallback(apiKey, parts);
        return parseTasksJson(rawJson);
    }

    private static List<TaskItem> callGeminiReplan(String apiKey, List<TaskItem> currentTasks) throws Exception {
        validateKey(apiKey);

        JSONArray existingArr = new JSONArray();
        for (TaskItem t : currentTasks) {
            JSONObject o = new JSONObject();
            o.put("title", t.title);
            o.put("category", t.category);
            o.put("priority", t.priority);
            o.put("due_date", t.dueDate);
            o.put("due_label", t.dueLabel);
            o.put("notes", t.notes);
            existingArr.put(o);
        }

        String prompt =
                "أنت خبير تخطيط وإدارة وقت. " + getCurrentDateTimeContext() + ".\n" +
                "أمامك قائمة مهام المستخدم الحالية. أعد ترتيبها بذكاء من الأهم فالأقل أهمية، ادمج أي مهام مكررة، حسّن صياغتها لتكون عملية، وحدّث الأولويات (عالية، متوسطة، عادية) والخطوة الأولى المختصرة في notes والمدة التقديرية estimated_minutes.\n" +
                "حافظ على جميع المهام الفعلية ولا تحذف أي مهمة غير مكررة.\n" +
                "أعد النتيجة بصيغة JSON فقط:\n" +
                "{\"tasks\": [{\"title\": \"...\", \"category\": \"...\", \"priority\": \"...\", \"due_date\": \"...\", \"due_label\": \"...\", \"notes\": \"...\", \"estimated_minutes\": 30}]}\n\n" +
                "المهام الحالية:\n" + existingArr.toString();

        JSONArray parts = new JSONArray();
        JSONObject p = new JSONObject();
        p.put("text", prompt);
        parts.put(p);

        String rawJson = executeWithFallback(apiKey, parts);
        return parseTasksJson(rawJson);
    }

    private static void validateKey(String apiKey) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new Exception("يرجى إدخال مفتاح Gemini API أولاً من زر الإعدادات (⚙️).");
        }
    }

    private static String executeWithFallback(String apiKey, JSONArray parts) throws Exception {
        Exception lastError = null;
        for (String model : MODELS) {
            try {
                return sendHttpRequest(apiKey.trim(), model, parts);
            } catch (Exception e) {
                lastError = e;
            }
        }
        throw (lastError != null) ? lastError : new Exception("تعذر الاتصال بخادم Gemini.");
    }

    private static String sendHttpRequest(String apiKey, String model, JSONArray parts) throws Exception {
        JSONObject contentObj = new JSONObject();
        contentObj.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(contentObj);

        JSONObject genConfig = new JSONObject();
        genConfig.put("responseMimeType", "application/json");
        genConfig.put("temperature", 0.2);

        JSONObject payload = new JSONObject();
        payload.put("contents", contents);
        payload.put("generationConfig", genConfig);

        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + apiKey;
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setConnectTimeout(25000);
        conn.setReadTimeout(40000);
        conn.setDoOutput(true);

        byte[] outBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(outBytes);
        }

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseBody = readStream(is);

        if (status < 200 || status >= 300) {
            throw new Exception("خطأ من Gemini (" + status + "): تحقق من المفتاح والإنترنت.");
        }

        JSONObject root = new JSONObject(responseBody);
        String rawText = root.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim();

        if (rawText.startsWith("```")) {
            rawText = rawText.replaceAll("^```[a-zA-Z]*\\n?", "").replaceAll("```$", "").trim();
        }
        return rawText;
    }

    private static List<TaskItem> parseTasksJson(String rawText) throws Exception {
        JSONObject parsed = new JSONObject(rawText);
        JSONArray taskArr = parsed.optJSONArray("tasks");
        List<TaskItem> result = new ArrayList<>();
        long now = System.currentTimeMillis();

        if (taskArr != null) {
            for (int i = 0; i < taskArr.length(); i++) {
                JSONObject o = taskArr.getJSONObject(i);
                String title = o.optString("title", "").trim();
                if (!title.isEmpty()) {
                    result.add(new TaskItem(
                            "t_" + now + "_" + i,
                            title,
                            o.optString("category", "عام"),
                            o.optString("priority", "متوسطة"),
                            o.optString("due_date", ""),
                            o.optString("due_label", ""),
                            o.optString("notes", ""),
                            o.optInt("estimated_minutes", 0),
                            false,
                            now + i,
                            0L,
                            0L
                    ));
                }
            }
        }
        return result;
    }

    private static byte[] readFileBytes(File file) throws Exception {
        try (FileInputStream fis = new FileInputStream(file);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = fis.read(buf)) != -1) {
                bos.write(buf, 0, len);
            }
            return bos.toByteArray();
        }
    }

    private static String readStream(InputStream is) throws Exception {
        if (is == null) return "";
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int len;
            while ((len = is.read(buf)) != -1) {
                bos.write(buf, 0, len);
            }
            return bos.toString("UTF-8");
        }
    }
}
