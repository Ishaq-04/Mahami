package com.ishaq.mahami;

import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {

    public interface Callback {
        void onSuccess(List<TaskItem> tasks);
        void onError(String message);
    }

    public interface ConnectionTestCallback {
        void onResult(boolean success, String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static volatile String cachedEndpoint = null;

    public static void resetEndpointCache() {
        cachedEndpoint = null;
    }

    public static void testConnection(final String apiKey, final ConnectionTestCallback callback) {
        EXECUTOR.execute(() -> {
            try {
                String cleanKey = validateKey(apiKey);
                JSONArray parts = new JSONArray();
                JSONObject p = new JSONObject();
                p.put("text", "أعد JSON فقط: {\"ok\": true}");
                parts.put(p);
                executeWithAutoDiscovery(cleanKey, parts);
                MAIN_HANDLER.post(() -> callback.onResult(true, "تم الاتصال بنجاح والمفتاح يعمل!"));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onResult(false, e.getMessage() != null ? e.getMessage() : "فشل الاتصال"));
            }
        });
    }

    public static void extractTasksFromText(final String apiKey, final String userText, final int defaultIntervalHours, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> tasks = callGeminiExtract(apiKey, userText, null, defaultIntervalHours);
                MAIN_HANDLER.post(() -> callback.onSuccess(tasks));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "خطأ غير معروف"));
            }
        });
    }

    public static void extractTasksFromAudio(final String apiKey, final File audioFile, final int defaultIntervalHours, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> tasks = callGeminiExtract(apiKey, null, audioFile, defaultIntervalHours);
                MAIN_HANDLER.post(() -> callback.onSuccess(tasks));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "خطأ في معالجة الصوت"));
            }
        });
    }

    public static void replanExistingTasks(final String apiKey, final List<TaskItem> currentTasks, final int defaultIntervalHours, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                List<TaskItem> replanned = callGeminiReplan(apiKey, currentTasks, defaultIntervalHours);
                MAIN_HANDLER.post(() -> callback.onSuccess(replanned));
            } catch (final Exception e) {
                MAIN_HANDLER.post(() -> callback.onError(e.getMessage() != null ? e.getMessage() : "تعذر إعادة الترتيب"));
            }
        });
    }

    private static String getCurrentDateTimeContext() {
        Date now = new Date();
        String isoDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now);
        String time24 = new SimpleDateFormat("HH:mm", Locale.US).format(now);
        String dayName = new SimpleDateFormat("EEEE", new Locale("ar")).format(now);
        return "التاريخ الحالي: " + isoDate + " (" + dayName + ")، الساعة الآن: " + time24;
    }

    private static List<TaskItem> callGeminiExtract(String apiKey, String textInput, File audioFile, int defaultIntervalHours) throws Exception {
        String cleanKey = validateKey(apiKey);

        String prompt =
                "أنت مدير مهام شخصي محترف باللغة العربية. " + getCurrentDateTimeContext() + ".\n" +
                "المطلوب: استخرج كل المهام من مدخل المستخدم (سواء كان نصاً عشوائياً أو تسجيلاً صوتياً باللهجة العراقية أو الفصحى).\n" +
                "قواعد صارمة:\n" +
                "1. صغ عنوان المهمة (title) بأسلوب تنفيذي واضح ومباشر ومختصر.\n" +
                "2. اختر التصنيف (category) حصراً من: دراسة، بحث، عمل، شخصي، عام.\n" +
                "3. حدد الأولوية (priority) بدقة: عالية، متوسطة، عادية.\n" +
                "4. إذا ذكر المستخدم موعداً في المستقبل (مثل: غداً، باجر، الخميس)، احسب تاريخه YYYY-MM-DD في due_date ووصفاً في due_label؛ وإلا اترك due_date فارغاً.\n" +
                "5. إذا ذكر المستخدم فترة تكرار للتنبيه (مثلاً: كل 3 ساعات أو كل 6 ساعات) ضع رقم الساعات (1 إلى 12) في repeat_hours، وإلا ضع " + defaultIntervalHours + ".\n" +
                "6. أضف ملاحظة تنفيذية قصيرة في notes وقدّر المدة بالدقائق في estimated_minutes.\n" +
                "أعد JSON فقط بهذا الشكل الدقيق:\n" +
                "{\"tasks\": [{\"title\": \"...\", \"category\": \"دراسة\", \"priority\": \"عالية\", \"due_date\": \"\", \"due_label\": \"اليوم\", \"notes\": \"...\", \"estimated_minutes\": 30, \"repeat_hours\": " + defaultIntervalHours + "}]}";

        JSONArray parts = new JSONArray();
        JSONObject promptPart = new JSONObject();
        promptPart.put("text", prompt);
        parts.put(promptPart);

        if (textInput != null) {
            JSONObject userPart = new JSONObject();
            userPart.put("text", "مدخل المستخدم:\n" + textInput);
            parts.put(userPart);
        } else if (audioFile != null && audioFile.exists()) {
            byte[] audioBytes = readFileBytes(audioFile);
            String base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP);
            JSONObject inlineData = new JSONObject();
            inlineData.put("mimeType", "audio/mp4");
            inlineData.put("data", base64Audio);
            JSONObject audioPart = new JSONObject();
            audioPart.put("inlineData", inlineData);
            parts.put(audioPart);
        }

        String rawJson = executeWithAutoDiscovery(cleanKey, parts);
        return parseTasksJson(rawJson, defaultIntervalHours);
    }

    private static List<TaskItem> callGeminiReplan(String apiKey, List<TaskItem> currentTasks, int defaultIntervalHours) throws Exception {
        String cleanKey = validateKey(apiKey);

        JSONArray existingArr = new JSONArray();
        for (TaskItem t : currentTasks) {
            JSONObject o = new JSONObject();
            o.put("title", t.title);
            o.put("category", t.category);
            o.put("priority", t.priority);
            o.put("due_date", t.dueDate);
            o.put("due_label", t.dueLabel);
            o.put("notes", t.notes);
            o.put("repeat_hours", t.repeatIntervalHours);
            existingArr.put(o);
        }

        String prompt =
                "أنت خبير تخطيط وإدارة وقت. " + getCurrentDateTimeContext() + ".\n" +
                "أعد ترتيب قائمة المهام التالية من الأهم فالأقل أهمية، ادمج أي مهام مكررة، حسّن صياغتها، وحدّث الأولويات والمدة التقديرية مع الحفاظ على repeat_hours لكل مهمة (من 1 إلى 12).\n" +
                "أعد النتيجة بصيغة JSON فقط:\n" +
                "{\"tasks\": [{\"title\": \"...\", \"category\": \"...\", \"priority\": \"...\", \"due_date\": \"...\", \"due_label\": \"...\", \"notes\": \"...\", \"estimated_minutes\": 30, \"repeat_hours\": 1}]}\n\n" +
                "المهام الحالية:\n" + existingArr.toString();

        JSONArray parts = new JSONArray();
        JSONObject p = new JSONObject();
        p.put("text", prompt);
        parts.put(p);

        String rawJson = executeWithAutoDiscovery(cleanKey, parts);
        return parseTasksJson(rawJson, defaultIntervalHours);
    }

    private static String validateKey(String apiKey) throws Exception {
        String clean = apiKey == null ? "" : apiKey.replaceAll("\\s+", "");
        if (clean.isEmpty()) {
            throw new Exception("يرجى إدخال مفتاح Gemini API أولاً من زر الإعدادات (⚙️).");
        }
        return clean;
    }

    private static String executeWithAutoDiscovery(String cleanKey, JSONArray parts) throws Exception {
        Set<String> endpoints = new LinkedHashSet<>();

        if (cachedEndpoint != null) {
            endpoints.add(cachedEndpoint);
        }

        // 1. الاستعلام الديناميكي أولاً عن النماذج المتاحة فعلياً على هذا المفتاح
        List<String> discovered = discoverModels(cleanKey);
        for (String modelPath : discovered) {
            endpoints.add("https://generativelanguage.googleapis.com/v1beta/" + modelPath + ":generateContent");
        }

        // 2. قائمة نماذج احتياطية حديثة على المسار الأصلي (يدعم مفاتيح AQ. و AIza عبر x-goog-api-key)
        String[] fallbackModels = new String[]{
                "gemini-2.5-flash",
                "gemini-2.5-flash-lite",
                "gemini-flash-latest",
                "gemini-3-flash-preview",
                "gemini-3.5-flash-lite",
                "gemini-2.0-flash"
        };
        for (String m : fallbackModels) {
            endpoints.add("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent");
        }

        Exception lastError = null;
        for (String endpoint : endpoints) {
            try {
                String res = sendPostRequest(endpoint, cleanKey, parts);
                cachedEndpoint = endpoint;
                return res;
            } catch (Exception e) {
                lastError = e;
            }
        }

        throw (lastError != null) ? lastError : new Exception("تعذر الاتصال بخادم Gemini.");
    }

    private static List<String> discoverModels(String cleanKey) {
        List<String> preferred = new ArrayList<>();
        List<String> others = new ArrayList<>();
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("x-goog-api-key", cleanKey);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);

            if (conn.getResponseCode() == 200) {
                String body = readStream(conn.getInputStream());
                JSONObject root = new JSONObject(body);
                JSONArray models = root.optJSONArray("models");
                if (models != null) {
                    for (int i = 0; i < models.length(); i++) {
                        JSONObject m = models.getJSONObject(i);
                        String name = m.optString("name", "");
                        String methods = m.optJSONArray("supportedGenerationMethods") != null
                                ? m.getJSONArray("supportedGenerationMethods").toString() : "";
                        if (!methods.contains("generateContent")) continue;
                        if (name.contains("flash") && !name.contains("image") && !name.contains("tts")) {
                            if (name.contains("2.5-flash") || name.contains("3-flash") || name.contains("3.5-flash")) {
                                preferred.add(name);
                            } else {
                                others.add(name);
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        preferred.addAll(others);
        return preferred;
    }

    private static String sendPostRequest(String endpoint, String cleanKey, JSONArray parts) throws Exception {
        JSONObject contentObj = new JSONObject();
        contentObj.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(contentObj);

        JSONObject genConfig = new JSONObject();
        genConfig.put("responseMimeType", "application/json");
        genConfig.put("temperature", 0.2);

        JSONObject payload = new JSONObject();
        payload.put("contents", contents);
        payload.put("generationConfig", genConfig);

        // تمرير المفتاح حصراً عبر ترويسة x-goog-api-key (بدون تكرار ?key= لتجنب تعارض المصادقة في مفاتيح AQ.)
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("x-goog-api-key", cleanKey);
        conn.setConnectTimeout(25000);
        conn.setReadTimeout(40000);
        conn.setDoOutput(true);

        byte[] outBytes = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(outBytes);
        }

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        String responseBody = readStream(is);

        if (status < 200 || status >= 300) {
            String apiMsg = extractErrorMessage(responseBody);
            throw new Exception("خطأ (" + status + "): " + apiMsg);
        }

        JSONObject root = new JSONObject(responseBody);
        String rawText = root.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim();

        if (rawText.startsWith("```")) {
            rawText = rawText.replaceAll("^```[a-zA-Z]*\\n?", "").replaceAll("```$", "").trim();
        }
        return rawText;
    }

    private static String extractErrorMessage(String responseBody) {
        try {
            JSONObject obj = new JSONObject(responseBody);
            if (obj.has("error")) {
                JSONObject err = obj.getJSONObject("error");
                String msg = err.optString("message", "");
                if (!msg.isEmpty()) return msg;
            }
        } catch (Exception ignored) {
        }
        return "تأكد من صحة المفتاح والإنترنت.";
    }

    private static List<TaskItem> parseTasksJson(String rawText, int defaultIntervalHours) throws Exception {
        JSONObject parsed = new JSONObject(rawText);
        JSONArray taskArr = parsed.optJSONArray("tasks");
        List<TaskItem> result = new ArrayList<>();
        long now = System.currentTimeMillis();

        if (taskArr != null) {
            for (int i = 0; i < taskArr.length(); i++) {
                JSONObject o = taskArr.getJSONObject(i);
                String title = o.optString("title", "").trim();
                if (!title.isEmpty()) {
                    String dueDate = o.optString("due_date", "");
                    int repeatHours = TaskItem.clampInterval(o.optInt("repeat_hours", defaultIntervalHours));
                    long nextAt = TaskItem.computeDefaultNextReminder(dueDate, repeatHours);
                    result.add(new TaskItem(
                            "t_" + now + "_" + i,
                            title,
                            o.optString("category", "عام"),
                            o.optString("priority", "متوسطة"),
                            dueDate,
                            o.optString("due_label", ""),
                            o.optString("notes", ""),
                            o.optInt("estimated_minutes", 0),
                            false,
                            now + i,
                            0L,
                            0L,
                            repeatHours,
                            nextAt,
                            true
                    ));
                }
            }
        }
        return result;
    }

    private static byte[] readFileBytes(File file) throws Exception {
        try (FileInputStream fis = new FileInputStream(file);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = fis.read(buf)) != -1) {
                bos.write(buf, 0, len);
            }
            return bos.toByteArray();
        }
    }

    private static String readStream(InputStream is) throws Exception {
        if (is == null) return "";
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int len;
            while ((len = is.read(buf)) != -1) {
                bos.write(buf, 0, len);
            }
            return bos.toString("UTF-8");
        }
    }
}
