package com.ishaq.mahami;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TaskItem {
    public String id;
    public String title;
    public String category;
    public String priority;        // عالية | متوسطة | عادية
    public String dueDate;         // YYYY-MM-DD أو فارغ
    public String dueLabel;        // اليوم | غداً | ...
    public String notes;
    public int estimatedMinutes;
    public boolean completed;
    public long createdAt;
    public long completedAt;
    public long snoozedUntil;

    // إعدادات التنبيه الفردية لكل مهمة
    public int repeatIntervalHours; // 1 إلى 12 ساعة
    public long nextReminderAt;     // الطابع الزمني الدقيق للتنبيه القادم لهذه المهمة
    public boolean reminderEnabled; // تفعيل أو إيقاف التنبيه لهذه المهمة

    public TaskItem(
            String id,
            String title,
            String category,
            String priority,
            String dueDate,
            String dueLabel,
            String notes,
            int estimatedMinutes,
            boolean completed,
            long createdAt,
            long completedAt,
            long snoozedUntil,
            int repeatIntervalHours,
            long nextReminderAt,
            boolean reminderEnabled
    ) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.priority = priority;
        this.dueDate = dueDate;
        this.dueLabel = dueLabel;
        this.notes = notes;
        this.estimatedMinutes = estimatedMinutes;
        this.completed = completed;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.snoozedUntil = snoozedUntil;
        this.repeatIntervalHours = clampInterval(repeatIntervalHours);
        this.nextReminderAt = nextReminderAt > 0 ? nextReminderAt : computeDefaultNextReminder(dueDate, this.repeatIntervalHours);
        this.reminderEnabled = reminderEnabled;
    }

    public static int clampInterval(int hours) {
        if (hours < 1) return 1;
        if (hours > 12) return 12;
        return hours;
    }

    public static long computeDefaultNextReminder(String dueDateIso, int intervalHours) {
        int safeHours = clampInterval(intervalHours);
        Calendar cal = Calendar.getInstance();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());

        if (dueDateIso != null && !dueDateIso.trim().isEmpty() && dueDateIso.trim().compareTo(today) > 0) {
            try {
                String[] parts = dueDateIso.trim().split("-");
                if (parts.length == 3) {
                    Calendar future = Calendar.getInstance();
                    future.set(Calendar.YEAR, Integer.parseInt(parts[0]));
                    future.set(Calendar.MONTH, Integer.parseInt(parts[1]) - 1);
                    future.set(Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
                    future.set(Calendar.HOUR_OF_DAY, 8);
                    future.set(Calendar.MINUTE, 0);
                    future.set(Calendar.SECOND, 0);
                    future.set(Calendar.MILLISECOND, 0);
                    return future.getTimeInMillis();
                }
            } catch (Exception ignored) {
            }
        }

        // محاذاة إلى رأس الساعة الملائم لفترة التكرار
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.HOUR_OF_DAY, safeHours);
        return cal.getTimeInMillis();
    }

    public static String formatIntervalLabel(int hours) {
        int h = clampInterval(hours);
        if (h == 1) return "كل ساعة";
        if (h == 2) return "كل ساعتين";
        if (h <= 10) return "كل " + h + " ساعات";
        return "كل " + h + " ساعة";
    }

    public static String[] getIntervalOptions() {
        String[] opts = new String[12];
        for (int i = 1; i <= 12; i++) {
            opts[i - 1] = formatIntervalLabel(i);
        }
        return opts;
    }

    public String getFormattedNextReminder() {
        if (!reminderEnabled) return "متوقف";
        if (nextReminderAt <= 0) return "غير محدد";
        Calendar target = Calendar.getInstance();
        target.setTimeInMillis(nextReminderAt);
        Calendar now = Calendar.getInstance();

        SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm a", new Locale("ar"));
        String timeStr = timeFmt.format(target.getTime());

        boolean sameDay = target.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                && target.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR);
        if (sameDay) {
            return timeStr;
        }
        SimpleDateFormat dayFmt = new SimpleDateFormat("d/M", Locale.US);
        return dayFmt.format(target.getTime()) + " • " + timeStr;
    }

    public boolean isSnoozedNow() {
        return snoozedUntil > System.currentTimeMillis();
    }

    public boolean isFutureScheduled() {
        if (dueDate == null || dueDate.trim().isEmpty()) return false;
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return dueDate.trim().compareTo(today) > 0;
    }

    public boolean isActiveForAlarm() {
        return !completed && reminderEnabled && !isSnoozedNow();
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("title", title);
        obj.put("category", category);
        obj.put("priority", priority);
        obj.put("dueDate", dueDate == null ? "" : dueDate);
        obj.put("dueLabel", dueLabel == null ? "" : dueLabel);
        obj.put("notes", notes == null ? "" : notes);
        obj.put("estimatedMinutes", estimatedMinutes);
        obj.put("completed", completed);
        obj.put("createdAt", createdAt);
        obj.put("completedAt", completedAt);
        obj.put("snoozedUntil", snoozedUntil);
        obj.put("repeatIntervalHours", repeatIntervalHours);
        obj.put("nextReminderAt", nextReminderAt);
        obj.put("reminderEnabled", reminderEnabled);
        return obj;
    }

    public static TaskItem fromJson(JSONObject obj) {
        int interval = clampInterval(obj.optInt("repeatIntervalHours", 1));
        String dueDate = obj.optString("dueDate", "");
        long nextAt = obj.optLong("nextReminderAt", 0L);
        boolean enabled = obj.optBoolean("reminderEnabled", true);
        return new TaskItem(
                obj.optString("id", "t_" + System.currentTimeMillis()),
                obj.optString("title", ""),
                obj.optString("category", "عام"),
                obj.optString("priority", "متوسطة"),
                dueDate,
                obj.optString("dueLabel", obj.optString("timeHint", "")),
                obj.optString("notes", ""),
                obj.optInt("estimatedMinutes", 0),
                obj.optBoolean("completed", false),
                obj.optLong("createdAt", System.currentTimeMillis()),
                obj.optLong("completedAt", 0L),
                obj.optLong("snoozedUntil", 0L),
                interval,
                nextAt,
                enabled
        );
    }
}
