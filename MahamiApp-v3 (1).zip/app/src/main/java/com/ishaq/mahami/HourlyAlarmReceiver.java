package com.ishaq.mahami;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HourlyAlarmReceiver extends BroadcastReceiver {

    public static final String ACTION_MARK_DONE = "com.ishaq.mahami.ACTION_MARK_DONE_NOTIF";
    public static final String EXTRA_TASK_ID = "extra_task_id";
    public static final String EXTRA_NOTIF_ID = "extra_notif_id";

    private static final String CHANNEL_REMINDER_VISUAL = "mahami_reminder_visual_v3";
    public static final int SUMMARY_NOTIF_ID = 1001;
    private static final int SEPARATE_BASE_ID = 5000;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && ACTION_MARK_DONE.equals(intent.getAction())) {
            String taskId = intent.getStringExtra(EXTRA_TASK_ID);
            int notifId = intent.getIntExtra(EXTRA_NOTIF_ID, SUMMARY_NOTIF_ID);
            if (taskId != null && !taskId.isEmpty()) {
                TaskStorage.markCompleted(context, taskId, true);
                AlarmScheduler.scheduleNextAlarm(context);
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(notifId);
            }
            return;
        }

        // استخراج المهام التي حان وقتها الآن وتحديث موعدها القادم حسب فترة تكرار كل مهمة (1-12 ساعة)
        List<TaskItem> dueTasks = TaskStorage.consumeDueTasksNow(context);
        // جدولة أقرب مهمة قادمة فوراً
        AlarmScheduler.scheduleNextAlarm(context);

        if (dueTasks.isEmpty()) {
            return;
        }

        fireShortAlert(context, dueTasks, false);
    }

    public static void fireTestAlert(Context context) {
        List<TaskItem> active = TaskStorage.getActiveAlarmTasks(context);
        fireShortAlert(context, active, true);
    }

    private static void fireShortAlert(Context context, List<TaskItem> tasks, boolean isTest) {
        String nowStr = new SimpleDateFormat("hh:mm a", new Locale("ar")).format(new Date());
        String shortTitle = tasks.isEmpty()
                ? "⏰ تجربة التنبيه القصير (" + nowStr + ")"
                : (tasks.size() == 1
                    ? "⏰ " + tasks.get(0).title
                    : "⏰ تذكير (" + nowStr + ") — " + tasks.size() + " مهام");
        String shortSummary = tasks.isEmpty()
                ? "مدة التنبيه: 1.5 ثانية"
                : "التكرار: " + TaskItem.formatIntervalLabel(tasks.get(0).repeatIntervalHours);

        // 1. عرض الإشعار المرئي المفصّل (بدون صوت إضافي لأن الخدمة تشغّل الصوت بدقة 1.5 ثانية فقط)
        postReminderNotification(context, tasks, nowStr, isTest);

        // 2. تشغيل نبضة صوت واهتزاز لمدة 1.5 ثانية فقط عبر الخدمة
        try {
            Intent pulseIntent = new Intent(context, AlarmRingingService.class);
            pulseIntent.setAction(AlarmRingingService.ACTION_PULSE);
            pulseIntent.putExtra(AlarmRingingService.EXTRA_TITLE, shortTitle);
            pulseIntent.putExtra(AlarmRingingService.EXTRA_SUMMARY, shortSummary);
            ContextCompat.startForegroundService(context, pulseIntent);
        } catch (Exception ignored) {
        }
    }

    private static void postReminderNotification(Context context, List<TaskItem> tasks, String nowStr, boolean isTest) {
        if (!hasNotificationPermission(context)) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannel(nm);

        PendingIntent openPi = buildOpenAppIntent(context);

        if (TaskStorage.isSeparateNotifs(context) && !tasks.isEmpty()) {
            for (int i = 0; i < Math.min(tasks.size(), 10); i++) {
                TaskItem t = tasks.get(i);
                int notifId = SEPARATE_BASE_ID + i;
                String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
                String title = "⏰ (" + nowStr + ") " + icon + " " + t.title;
                String body = "📂 " + t.category
                        + " • 🔁 " + TaskItem.formatIntervalLabel(t.repeatIntervalHours)
                        + ((t.notes != null && !t.notes.isEmpty()) ? "\n💡 " + t.notes : "");

                NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_REMINDER_VISUAL)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_ALARM)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setContentIntent(openPi)
                        .addAction(android.R.drawable.checkbox_on_background, "✅ إنجاز", buildMarkDoneIntent(context, t.id, notifId))
                        .setAutoCancel(true);

                nm.notify(notifId, b.build());
            }
            return;
        }

        String title;
        String summary;
        NotificationCompat.InboxStyle inbox = new NotificationCompat.InboxStyle();

        if (tasks.isEmpty()) {
            title = "⏰ تجربة التنبيه (" + nowStr + ")";
            summary = "تم إطلاق تنبيه لمدة 1.5 ثانية بنجاح.";
            inbox.addLine(summary);
        } else if (tasks.size() == 1) {
            TaskItem t = tasks.get(0);
            String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
            title = "⏰ (" + nowStr + ") " + icon + " " + t.title;
            summary = "📂 " + t.category + " • 🔁 " + TaskItem.formatIntervalLabel(t.repeatIntervalHours);
            inbox.addLine(summary);
            if (t.notes != null && !t.notes.isEmpty()) inbox.addLine("💡 " + t.notes);
        } else {
            title = "⏰ تذكير (" + nowStr + ") — " + tasks.size() + " مهام حان موعدها";
            summary = "افتح التطبيق لإنجاز مهامك أو تعديل توقيتها";
            for (int i = 0; i < tasks.size(); i++) {
                TaskItem t = tasks.get(i);
                String icon = "عالية".equals(t.priority) ? "🔴" : ("متوسطة".equals(t.priority) ? "🟡" : "🟢");
                inbox.addLine((i + 1) + ". " + icon + " " + t.title + " (" + TaskItem.formatIntervalLabel(t.repeatIntervalHours) + ")");
            }
        }
        inbox.setBigContentTitle(title);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_REMINDER_VISUAL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(summary)
                .setStyle(inbox)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(openPi)
                .setAutoCancel(true);

        if (tasks.size() == 1) {
            builder.addAction(
                    android.R.drawable.checkbox_on_background,
                    "✅ إنجاز المهمة",
                    buildMarkDoneIntent(context, tasks.get(0).id, SUMMARY_NOTIF_ID)
            );
        }

        nm.notify(SUMMARY_NOTIF_ID, builder.build());
    }

    public static void cancelAllNotifications(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(SUMMARY_NOTIF_ID);
            for (int i = 0; i < 10; i++) {
                nm.cancel(SEPARATE_BASE_ID + i);
            }
        }
    }

    private static PendingIntent buildOpenAppIntent(Context context) {
        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(
                context, 3001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static PendingIntent buildMarkDoneIntent(Context context, String taskId, int notifId) {
        Intent doneIntent = new Intent(context, HourlyAlarmReceiver.class);
        doneIntent.setAction(ACTION_MARK_DONE);
        doneIntent.putExtra(EXTRA_TASK_ID, taskId);
        doneIntent.putExtra(EXTRA_NOTIF_ID, notifId);
        return PendingIntent.getBroadcast(
                context,
                6000 + Math.abs(taskId.hashCode() % 1000),
                doneIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private static void ensureChannel(NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (nm.getNotificationChannel(CHANNEL_REMINDER_VISUAL) == null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_REMINDER_VISUAL,
                        "إشعارات المهام المجدولة",
                        NotificationManager.IMPORTANCE_HIGH
                );
                ch.setDescription("يعرض بطاقة المهمة بالتزامن مع نبضة التنبيه القصيرة (1.5 ثانية)");
                // الصوت والاهتزاز تُدار بدقة عبر AlarmRingingService لمدة 1.5 ثانية فقط لمنع الإطالة
                ch.setSound(null, null);
                ch.enableVibration(false);
                ch.setBypassDnd(true);
                nm.createNotificationChannel(ch);
            }
        }
    }
}
