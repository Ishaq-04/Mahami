package com.ishaq.mahami;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TaskStorage {
    private static final String PREFS_NAME = "mahami_prefs_v2";
    private static final String KEY_API = "gemini_api_key";
    private static final String KEY_TASKS = "tasks_json_v2";
    private static final String KEY_USE_ALARM_STREAM = "use_alarm_stream_v3";
    private static final String KEY_SEPARATE_NOTIFS = "separate_notifs";
    private static final String KEY_DEFAULT_INTERVAL = "default_interval_hours";

    private static SharedPreferences getPrefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static String getApiKey(Context context) {
        String key = getPrefs(context).getString(KEY_API, "").replaceAll("\\s+", "");
        if (key.isEmpty()) {
            SharedPreferences oldPrefs = context.getApplicationContext()
                    .getSharedPreferences("mahami_prefs", Context.MODE_PRIVATE);
            key = oldPrefs.getString(KEY_API, "").replaceAll("\\s+", "");
            if (!key.isEmpty()) {
                setApiKey(context, key);
            }
        }
        return key;
    }

    public static void setApiKey(Context context, String apiKey) {
        String clean = apiKey == null ? "" : apiKey.replaceAll("\\s+", "");
        getPrefs(context).edit().putString(KEY_API, clean).apply();
        GeminiClient.resetEndpointCache();
    }

    public static boolean isUseAlarmStream(Context context) {
        return getPrefs(context).getBoolean(KEY_USE_ALARM_STREAM, true);
    }

    public static void setUseAlarmStream(Context context, boolean enabled) {
        getPrefs(context).edit().putBoolean(KEY_USE_ALARM_STREAM, enabled).apply();
    }

    public static boolean isSeparateNotifs(Context context) {
        return getPrefs(context).getBoolean(KEY_SEPARATE_NOTIFS, false);
    }

    public static void setSeparateNotifs(Context context, boolean enabled) {
        getPrefs(context).edit().putBoolean(KEY_SEPARATE_NOTIFS, enabled).apply();
    }

    public static int getDefaultIntervalHours(Context context) {
        return TaskItem.clampInterval(getPrefs(context).getInt(KEY_DEFAULT_INTERVAL, 1));
    }

    public static void setDefaultIntervalHours(Context context, int hours) {
        getPrefs(context).edit().putInt(KEY_DEFAULT_INTERVAL, TaskItem.clampInterval(hours)).apply();
    }

    public static synchronized List<TaskItem> getAllTasks(Context context) {
        String raw = getPrefs(context).getString(KEY_TASKS, "[]");
        List<TaskItem> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) {
                    list.add(TaskItem.fromJson(obj));
                }
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static synchronized List<TaskItem> getPendingTasks(Context context) {
        List<TaskItem> all = getAllTasks(context);
        List<TaskItem> pending = new ArrayList<>();
        for (TaskItem t : all) {
            if (!t.completed) pending.add(t);
        }
        sortPending(pending);
        return pending;
    }

    public static synchronized List<TaskItem> getActiveAlarmTasks(Context context) {
        List<TaskItem> pending = getPendingTasks(context);
        List<TaskItem> active = new ArrayList<>();
        for (TaskItem t : pending) {
            if (t.isActiveForAlarm()) {
                active.add(t);
            }
        }
        return active;
    }

    /**
     * يستخرج المهام التي حان وقت تنبيهها الآن ويدفع موعد تنبيهها القادم بمقدار repeatIntervalHours لكل مهمة على حدة
     */
    public static synchronized List<TaskItem> consumeDueTasksNow(Context context) {
        long now = System.currentTimeMillis();
        long toleranceMs = 75_000L; // هامش 75 ثانية لضمان التقاط المهام القريبة في نفس الدقيقة
        List<TaskItem> all = getAllTasks(context);
        List<TaskItem> triggered = new ArrayList<>();
        boolean modified = false;

        for (TaskItem t : all) {
            if (!t.isActiveForAlarm()) continue;
            if (t.nextReminderAt <= now + toleranceMs) {
                triggered.add(t);
                long stepMs = TaskItem.clampInterval(t.repeatIntervalHours) * 3_600_000L;
                if (t.nextReminderAt <= 0) {
                    t.nextReminderAt = TaskItem.computeDefaultNextReminder(t.dueDate, t.repeatIntervalHours);
                } else {
                    while (t.nextReminderAt <= now + toleranceMs) {
                        t.nextReminderAt += stepMs;
                    }
                }
                modified = true;
            }
        }

        if (modified) {
            saveAllTasks(context, all);
        }
        sortPending(triggered);
        return triggered;
    }

    /**
     * يضمن أن كل مهمة نشطة لها موعد تنبيه مستقبلي صالح، ويعيد أقرب مهمة قادمة
     */
    public static synchronized TaskItem ensureFutureScheduleAndGetEarliest(Context context) {
        long now = System.currentTimeMillis();
        List<TaskItem> all = getAllTasks(context);
        boolean modified = false;
        TaskItem earliest = null;

        for (TaskItem t : all) {
            if (!t.isActiveForAlarm()) continue;
            long stepMs = TaskItem.clampInterval(t.repeatIntervalHours) * 3_600_000L;
            if (t.nextReminderAt <= 0) {
                t.nextReminderAt = TaskItem.computeDefaultNextReminder(t.dueDate, t.repeatIntervalHours);
                modified = true;
            } else if (t.nextReminderAt <= now) {
                while (t.nextReminderAt <= now) {
                    t.nextReminderAt += stepMs;
                }
                modified = true;
            }
            if (earliest == null || t.nextReminderAt < earliest.nextReminderAt) {
                earliest = t;
            }
        }

        if (modified) {
            saveAllTasks(context, all);
        }
        return earliest;
    }

    public static synchronized List<TaskItem> getCompletedTasks(Context context) {
        List<TaskItem> all = getAllTasks(context);
        List<TaskItem> done = new ArrayList<>();
        for (TaskItem t : all) {
            if (t.completed) done.add(t);
        }
        Collections.sort(done, new Comparator<TaskItem>() {
            @Override
            public int compare(TaskItem a, TaskItem b) {
                return Long.compare(b.completedAt, a.completedAt);
            }
        });
        return done;
    }

    public static synchronized int getCompletedTodayCount(Context context) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        int count = 0;
        for (TaskItem t : getCompletedTasks(context)) {
            if (t.completedAt > 0 && today.equals(sdf.format(new Date(t.completedAt)))) {
                count++;
            }
        }
        return count;
    }

    private static void sortPending(List<TaskItem> list) {
        Collections.sort(list, new Comparator<TaskItem>() {
            @Override
            public int compare(TaskItem a, TaskItem b) {
                boolean aFuture = a.isFutureScheduled();
                boolean bFuture = b.isFutureScheduled();
                if (aFuture != bFuture) {
                    return aFuture ? 1 : -1;
                }
                int pDiff = priorityRank(a.priority) - priorityRank(b.priority);
                if (pDiff != 0) return pDiff;
                return Long.compare(a.nextReminderAt, b.nextReminderAt);
            }
        });
    }

    private static int priorityRank(String priority) {
        if ("عالية".equals(priority)) return 1;
        if ("متوسطة".equals(priority)) return 2;
        return 3;
    }

    public static synchronized void saveAllTasks(Context context, List<TaskItem> tasks) {
        JSONArray arr = new JSONArray();
        try {
            for (TaskItem t : tasks) {
                arr.put(t.toJson());
            }
        } catch (Exception ignored) {
        }
        getPrefs(context).edit().putString(KEY_TASKS, arr.toString()).apply();
    }

    public static synchronized void addTasks(Context context, List<TaskItem> newTasks) {
        List<TaskItem> all = getAllTasks(context);
        all.addAll(newTasks);
        saveAllTasks(context, all);
    }

    public static synchronized void replacePendingTasks(Context context, List<TaskItem> replannedPending) {
        List<TaskItem> completed = getCompletedTasks(context);
        List<TaskItem> merged = new ArrayList<>();
        merged.addAll(replannedPending);
        merged.addAll(completed);
        saveAllTasks(context, merged);
    }

    public static synchronized void updateTask(Context context, TaskItem updated) {
        List<TaskItem> all = getAllTasks(context);
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(updated.id)) {
                all.set(i, updated);
                break;
            }
        }
        saveAllTasks(context, all);
    }

    public static synchronized void markCompleted(Context context, String taskId, boolean completed) {
        List<TaskItem> all = getAllTasks(context);
        for (TaskItem t : all) {
            if (t.id.equals(taskId)) {
                t.completed = completed;
                t.completedAt = completed ? System.currentTimeMillis() : 0L;
                if (!completed) {
                    t.snoozedUntil = 0L;
                    t.reminderEnabled = true;
                    t.nextReminderAt = TaskItem.computeDefaultNextReminder(t.dueDate, t.repeatIntervalHours);
                }
                break;
            }
        }
        saveAllTasks(context, all);
    }

    public static synchronized void snoozeTaskUntilTomorrow(Context context, String taskId) {
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_YEAR, 1);
        tomorrow.set(Calendar.HOUR_OF_DAY, 8);
        tomorrow.set(Calendar.MINUTE, 0);
        tomorrow.set(Calendar.SECOND, 0);
        tomorrow.set(Calendar.MILLISECOND, 0);

        String tomorrowIso = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(tomorrow.getTime());

        List<TaskItem> all = getAllTasks(context);
        for (TaskItem t : all) {
            if (t.id.equals(taskId)) {
                t.snoozedUntil = 0L;
                t.dueDate = tomorrowIso;
                t.dueLabel = "مؤجلة للغد";
                t.nextReminderAt = tomorrow.getTimeInMillis();
                break;
            }
        }
        saveAllTasks(context, all);
    }

    public static synchronized void deleteTask(Context context, String taskId) {
        List<TaskItem> all = getAllTasks(context);
        List<TaskItem> remaining = new ArrayList<>();
        for (TaskItem t : all) {
            if (!t.id.equals(taskId)) {
                remaining.add(t);
            }
        }
        saveAllTasks(context, remaining);
    }

    public static synchronized void clearCompleted(Context context) {
        saveAllTasks(context, getPendingTasks(context));
    }

    public static synchronized String exportBackupJson(Context context) {
        return getPrefs(context).getString(KEY_TASKS, "[]");
    }

    public static synchronized int importBackupJson(Context context, String jsonText) throws Exception {
        JSONArray arr = new JSONArray(jsonText.trim());
        List<TaskItem> imported = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj != null) {
                imported.add(TaskItem.fromJson(obj));
            }
        }
        saveAllTasks(context, imported);
        return imported.size();
    }
}
