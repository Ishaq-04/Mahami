package com.ishaq.mahami;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class AlarmRingingService extends Service {

    public static final String ACTION_PULSE = "com.ishaq.mahami.ACTION_PULSE_ALERT";
    public static final String EXTRA_TITLE = "extra_title";
    public static final String EXTRA_SUMMARY = "extra_summary";

    private static final String CHANNEL_PULSE = "mahami_pulse_service_v3";
    private static final int PULSE_NOTIF_ID = 2030;
    // مدة التنبيه الصوتي والاهتزاز: 1.5 ثانية (ضمن النطاق المطلوب: ثانية إلى ثانيتين فقط)
    private static final long ALERT_DURATION_MS = 1_500L;

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable stopPulseRunnable = new Runnable() {
        @Override
        public void run() {
            stopAndFinish();
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = (intent != null && intent.getStringExtra(EXTRA_TITLE) != null)
                ? intent.getStringExtra(EXTRA_TITLE)
                : "⏰ تذكير مهمة";
        String summary = (intent != null && intent.getStringExtra(EXTRA_SUMMARY) != null)
                ? intent.getStringExtra(EXTRA_SUMMARY)
                : "افتح تطبيق مهامي";

        ensurePulseChannel();
        Notification fgNotif = buildForegroundNotif(title, summary);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(PULSE_NOTIF_ID, fgNotif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(PULSE_NOTIF_ID, fgNotif);
        }

        acquireWakeLock();
        startShortAlertSound();
        startShortVibration();

        handler.removeCallbacks(stopPulseRunnable);
        handler.postDelayed(stopPulseRunnable, ALERT_DURATION_MS);

        return START_NOT_STICKY;
    }

    private Notification buildForegroundNotif(String title, String summary) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 4100, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_PULSE)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(summary)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setSilent(true)
                .setContentIntent(pi)
                .build();
    }

    private void ensurePulseChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_PULSE) == null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_PULSE,
                        "مؤقت صوت التنبيه القصير",
                        NotificationManager.IMPORTANCE_LOW
                );
                ch.setSound(null, null);
                ch.enableVibration(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void startShortAlertSound() {
        stopAlertSound();
        try {
            boolean useAlarm = TaskStorage.isUseAlarmStream(this);
            Uri soundUri = useAlarm
                    ? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(useAlarm ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mediaPlayer.setDataSource(this, soundUri);
            mediaPlayer.setLooping(false);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception ignored) {
        }
    }

    private void stopAlertSound() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
    }

    private void startShortVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vibrator = vm.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                // إجمالي 1500 مللي ثانية (نبضتان واضحتان بدون تكرار)
                long[] pattern = new long[]{0, 600, 200, 700};
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
            }
        } catch (Exception ignored) {
        }
    }

    private void stopVibration() {
        if (vibrator != null) {
            try {
                vibrator.cancel();
            } catch (Exception ignored) {
            }
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mahami:ShortAlertLock");
                wakeLock.acquire(3_000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {
            }
        }
        wakeLock = null;
    }

    private void stopAndFinish() {
        handler.removeCallbacks(stopPulseRunnable);
        stopAlertSound();
        stopVibration();
        releaseWakeLock();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(stopPulseRunnable);
        stopAlertSound();
        stopVibration();
        releaseWakeLock();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
