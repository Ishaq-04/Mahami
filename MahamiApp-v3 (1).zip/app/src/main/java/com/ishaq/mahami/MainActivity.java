package com.ishaq.mahami;

import android.Manifest;
import android.app.AlarmManager;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_NOTIF = 101;
    private static final int REQ_AUDIO = 102;

    private static final int TAB_TODAY = 0;
    private static final int TAB_UPCOMING = 1;
    private static final int TAB_ALL = 2;
    private static final int TAB_DONE = 3;

    private int activeTab = TAB_ALL;

    private EditText taskInput;
    private Button btnProcessText;
    private Button btnRecordVoice;
    private Button btnManualAdd;
    private Button btnSmartReplan;
    private Button btnBatteryExempt;
    private ProgressBar progressBar;
    private TextView tvAlarmStatus;
    private TextView tvStatsPending;
    private TextView tvStatsUrgent;
    private TextView tvStatsDone;
    private ProgressBar dailyProgressBar;
    private LinearLayout tabsRow;
    private LinearLayout tasksContainer;

    private MediaRecorder mediaRecorder;
    private File currentAudioFile;
    private boolean isRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildUi();
        requestNeededPermissions();
        AlarmScheduler.scheduleNextAlarm(this);
        refreshUi();

        if (TaskStorage.getApiKey(this).isEmpty()) {
            showSettingsDialog(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AlarmScheduler.scheduleNextAlarm(this);
        refreshUi();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.parseColor("#F1F5F9"));
        scrollView.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // 1. Header Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(Color.parseColor("#0B1F3A"));
        header.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout headerTop = new LinearLayout(this);
        headerTop.setOrientation(LinearLayout.HORIZONTAL);
        headerTop.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvAppTitle = new TextView(this);
        tvAppTitle.setText("مهامي الذكية v3");
        tvAppTitle.setTextColor(Color.WHITE);
        tvAppTitle.setTextSize(20);
        tvAppTitle.setTypeface(null, Typeface.BOLD);

        String todayArabic = new SimpleDateFormat("EEEE، d MMMM yyyy", new Locale("ar")).format(new Date());
        TextView tvDate = new TextView(this);
        tvDate.setText(todayArabic);
        tvDate.setTextColor(Color.parseColor("#94A3B8"));
        tvDate.setTextSize(12);

        titleBox.addView(tvAppTitle);
        titleBox.addView(tvDate);

        Button btnTest = makeSmallHeaderBtn("🔔 تجربة", "#1E3A8A");
        btnTest.setOnClickListener(v -> {
            HourlyAlarmReceiver.fireTestAlert(this);
            Toast.makeText(this, "تجربة التنبيه (1.5 ثانية)...", Toast.LENGTH_SHORT).show();
        });

        Button btnSettings = makeSmallHeaderBtn("⚙️ الإعدادات", "#1E293B");
        LinearLayout.LayoutParams setLp = (LinearLayout.LayoutParams) btnSettings.getLayoutParams();
        setLp.setMarginStart(dp(6));
        btnSettings.setOnClickListener(v -> showSettingsDialog(false));

        headerTop.addView(titleBox);
        headerTop.addView(btnTest);
        headerTop.addView(btnSettings);
        header.addView(headerTop);

        // Stats Strip
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams statsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statsLp.topMargin = dp(12);
        statsRow.setLayoutParams(statsLp);

        tvStatsPending = addStatChip(statsRow, "المتبقية", "#1E293B", "#F8FAFC");
        tvStatsUrgent = addStatChip(statsRow, "عاجلة", "#450A0A", "#FCA5A5");
        tvStatsDone = addStatChip(statsRow, "أُنجزت اليوم", "#052E16", "#86EFAC");
        header.addView(statsRow);

        dailyProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        dailyProgressBar.setMax(100);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(6));
        pbLp.topMargin = dp(10);
        dailyProgressBar.setLayoutParams(pbLp);
        header.addView(dailyProgressBar);

        root.addView(header);

        // Main Body
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12), dp(12), dp(12), dp(28));

        // 2. Alarm Banner Card
        LinearLayout alarmCard = makeRoundedCard("#FFFFFF", "#CBD5E1");
        tvAlarmStatus = new TextView(this);
        tvAlarmStatus.setTextColor(Color.parseColor("#0B1F3A"));
        tvAlarmStatus.setTextSize(13);
        tvAlarmStatus.setTypeface(null, Typeface.BOLD);
        alarmCard.addView(tvAlarmStatus);

        btnBatteryExempt = makePillButton("⚡ تفعيل العمل الدائم أثناء النوم (ضروري)", "#B45309");
        LinearLayout.LayoutParams batLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        batLp.topMargin = dp(8);
        btnBatteryExempt.setLayoutParams(batLp);
        btnBatteryExempt.setOnClickListener(v -> requestBatteryExemption());
        alarmCard.addView(btnBatteryExempt);
        body.addView(alarmCard);

        // 3. AI Smart Input Card
        LinearLayout inputCard = makeRoundedCard("#FFFFFF", "#E2E8F0");

        TextView tvInTitle = new TextView(this);
        tvInTitle.setText("أرسل مهامك بعشوائية (كتابة أو صوت) وسأفرزها وأجدولها:");
        tvInTitle.setTextColor(Color.parseColor("#0F172A"));
        tvInTitle.setTextSize(14);
        tvInTitle.setTypeface(null, Typeface.BOLD);

        taskInput = new EditText(this);
        taskInput.setHint("مثال: أدرس محاضرة الأدوية اليوم كل ساعتين، أبحث عن مصادر البحث...");
        taskInput.setMinLines(3);
        taskInput.setMaxLines(6);
        taskInput.setGravity(Gravity.TOP | Gravity.START);
        taskInput.setTextColor(Color.parseColor("#0F172A"));
        taskInput.setTextSize(14);
        taskInput.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable inBg = new GradientDrawable();
        inBg.setColor(Color.parseColor("#F8FAFC"));
        inBg.setCornerRadius(dp(10));
        inBg.setStroke(dp(1), Color.parseColor("#CBD5E1"));
        taskInput.setBackground(inBg);
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        inLp.topMargin = dp(8);
        taskInput.setLayoutParams(inLp);

        LinearLayout btnRow1 = new LinearLayout(this);
        btnRow1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r1Lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        r1Lp.topMargin = dp(10);
        btnRow1.setLayoutParams(r1Lp);

        btnProcessText = makePillButton("✨ رتّب وجدوِل", "#0B1F3A");
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(44), 1.3f);
        btnProcessText.setLayoutParams(p1);
        btnProcessText.setOnClickListener(v -> handleTextSubmit());

        btnRecordVoice = makePillButton("🎤 تسجيل صوتي", "#15803D");
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p2.setMarginStart(dp(8));
        btnRecordVoice.setLayoutParams(p2);
        btnRecordVoice.setOnClickListener(v -> toggleVoiceRecording());

        btnRow1.addView(btnProcessText);
        btnRow1.addView(btnRecordVoice);

        LinearLayout btnRow2 = new LinearLayout(this);
        btnRow2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2Lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        r2Lp.topMargin = dp(8);
        btnRow2.setLayoutParams(r2Lp);

        btnSmartReplan = makePillButton("🧠 إعادة ترتيب ذكية", "#2563EB");
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        btnSmartReplan.setLayoutParams(p3);
        btnSmartReplan.setOnClickListener(v -> handleSmartReplan());

        btnManualAdd = makePillButton("➕ إضافة يدوية", "#475569");
        LinearLayout.LayoutParams p4 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        p4.setMarginStart(dp(8));
        btnManualAdd.setLayoutParams(p4);
        btnManualAdd.setOnClickListener(v -> showEditTaskDialog(null));

        btnRow2.addView(btnSmartReplan);
        btnRow2.addView(btnManualAdd);

        progressBar = new ProgressBar(this);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        loadLp.gravity = Gravity.CENTER_HORIZONTAL;
        loadLp.topMargin = dp(8);
        progressBar.setLayoutParams(loadLp);

        inputCard.addView(tvInTitle);
        inputCard.addView(taskInput);
        inputCard.addView(btnRow1);
        inputCard.addView(btnRow2);
        inputCard.addView(progressBar);
        body.addView(inputCard);

        // 4. Filter Tabs Row
        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tabsLp.topMargin = dp(4);
        tabsLp.bottomMargin = dp(10);
        tabsRow.setLayoutParams(tabsLp);
        body.addView(tabsRow);

        // 5. Tasks Container
        tasksContainer = new LinearLayout(this);
        tasksContainer.setOrientation(LinearLayout.VERTICAL);
        body.addView(tasksContainer);

        root.addView(body);
        scrollView.addView(root);
        setContentView(scrollView);
    }

    private TextView addStatChip(LinearLayout parent, String label, String bgHex, String textHex) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), dp(8), dp(6), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(10));
        box.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (parent.getChildCount() > 0) lp.setMarginStart(dp(6));
        box.setLayoutParams(lp);

        TextView tvNum = new TextView(this);
        tvNum.setText("0");
        tvNum.setTextColor(Color.parseColor(textHex));
        tvNum.setTextSize(18);
        tvNum.setTypeface(null, Typeface.BOLD);
        tvNum.setGravity(Gravity.CENTER);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextColor(Color.parseColor("#CBD5E1"));
        tvLbl.setTextSize(11);
        tvLbl.setGravity(Gravity.CENTER);

        box.addView(tvNum);
        box.addView(tvLbl);
        parent.addView(box);
        return tvNum;
    }

    private void rebuildTabs(int allCount, int todayCount, int upcomingCount, int doneCount) {
        tabsRow.removeAllViews();
        addTabButton("الكل (" + allCount + ")", TAB_ALL);
        addTabButton("اليوم (" + todayCount + ")", TAB_TODAY);
        addTabButton("القادمة (" + upcomingCount + ")", TAB_UPCOMING);
        addTabButton("المنجزة (" + doneCount + ")", TAB_DONE);
    }

    private void addTabButton(String title, final int tabIndex) {
        TextView tab = new TextView(this);
        tab.setText(title);
        tab.setTextSize(12);
        tab.setGravity(Gravity.CENTER);
        tab.setPadding(dp(4), dp(8), dp(4), dp(8));
        boolean selected = (activeTab == tabIndex);
        tab.setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
        tab.setTextColor(selected ? Color.WHITE : Color.parseColor("#334155"));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? Color.parseColor("#0B1F3A") : Color.WHITE);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), selected ? Color.parseColor("#0B1F3A") : Color.parseColor("#CBD5E1"));
        tab.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (tabsRow.getChildCount() > 0) lp.setMarginStart(dp(5));
        tab.setLayoutParams(lp);

        tab.setOnClickListener(v -> {
            activeTab = tabIndex;
            refreshUi();
        });
        tabsRow.addView(tab);
    }

    private void refreshUi() {
        TaskItem earliest = AlarmScheduler.scheduleNextAlarm(this);
        List<TaskItem> pending = TaskStorage.getPendingTasks(this);
        List<TaskItem> completed = TaskStorage.getCompletedTasks(this);

        int urgentCount = 0;
        int todayCount = 0;
        int upcomingCount = 0;
        for (TaskItem t : pending) {
            if ("عالية".equals(t.priority)) urgentCount++;
            if (t.isFutureScheduled()) upcomingCount++;
            else todayCount++;
        }

        int doneToday = TaskStorage.getCompletedTodayCount(this);
        tvStatsPending.setText(String.valueOf(pending.size()));
        tvStatsUrgent.setText(String.valueOf(urgentCount));
        tvStatsDone.setText(String.valueOf(doneToday));

        int totalTodayScope = todayCount + doneToday;
        int progressPct = totalTodayScope == 0 ? 100 : Math.round((doneToday * 100f) / totalTodayScope);
        dailyProgressBar.setProgress(progressPct);

        if (earliest == null) {
            tvAlarmStatus.setText("⏰ لا توجد تنبيهات نشطة حالياً • مدة التنبيه: 1.5 ثانية");
            HourlyAlarmReceiver.cancelAllNotifications(this);
        } else {
            String shortName = earliest.title.length() > 24 ? earliest.title.substring(0, 24) + "..." : earliest.title;
            tvAlarmStatus.setText("⏰ التنبيه القادم: " + earliest.getFormattedNextReminder()
                    + " (" + shortName + " • " + TaskItem.formatIntervalLabel(earliest.repeatIntervalHours) + ") • 1.5 ثانية");
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
            btnBatteryExempt.setVisibility(View.GONE);
        } else {
            btnBatteryExempt.setVisibility(View.VISIBLE);
        }

        rebuildTabs(pending.size(), todayCount, upcomingCount, completed.size());
        renderTaskCards(pending, completed);
    }

    private void renderTaskCards(List<TaskItem> pending, List<TaskItem> completed) {
        tasksContainer.removeAllViews();
        List<TaskItem> filtered = new ArrayList<>();

        if (activeTab == TAB_DONE) {
            filtered.addAll(completed);
            if (!completed.isEmpty()) {
                Button btnClearDone = makePillButton("🗑️ تفريغ سجل المنجَزة", "#64748B");
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(38));
                lp.bottomMargin = dp(10);
                btnClearDone.setLayoutParams(lp);
                btnClearDone.setOnClickListener(v -> {
                    TaskStorage.clearCompleted(this);
                    refreshUi();
                });
                tasksContainer.addView(btnClearDone);
            }
        } else {
            for (TaskItem t : pending) {
                if (activeTab == TAB_ALL) filtered.add(t);
                else if (activeTab == TAB_TODAY && !t.isFutureScheduled()) filtered.add(t);
                else if (activeTab == TAB_UPCOMING && t.isFutureScheduled()) filtered.add(t);
            }
        }

        if (filtered.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText(activeTab == TAB_DONE
                    ? "لا توجد مهام منجزة في السجل بعد."
                    : "لا توجد مهام في هذا القسم. أرسل مهامك في الأعلى وسيقوم التطبيق بترتيبها وإعطائك تحكماً كاملاً بتوقيت وتكرار كل مهمة.");
            tvEmpty.setTextColor(Color.parseColor("#64748B"));
            tvEmpty.setTextSize(14);
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(dp(12), dp(24), dp(12), dp(24));
            tasksContainer.addView(tvEmpty);
            return;
        }

        for (final TaskItem item : filtered) {
            tasksContainer.addView(buildTaskCardView(item));
        }
    }

    private View buildTaskCardView(final TaskItem item) {
        String strokeColor = item.completed ? "#86EFAC"
                : (!item.reminderEnabled ? "#94A3B8"
                : ("عالية".equals(item.priority) ? "#EF4444"
                : ("متوسطة".equals(item.priority) ? "#F59E0B" : "#22C55E")));

        LinearLayout card = makeRoundedCard("#FFFFFF", strokeColor);

        String badge = item.completed ? "✅ منجزة"
                : ("عالية".equals(item.priority) ? "🔴 عالية"
                : ("متوسطة".equals(item.priority) ? "🟡 متوسطة" : "🟢 عادية"));

        StringBuilder meta = new StringBuilder();
        meta.append(badge).append("  •  📂 ").append(item.category);
        if (item.dueLabel != null && !item.dueLabel.isEmpty()) {
            meta.append("  •  📅 ").append(item.dueLabel);
        }
        if (item.estimatedMinutes > 0) {
            meta.append("  •  ⏱ ").append(item.estimatedMinutes).append(" د");
        }

        TextView tvMeta = new TextView(this);
        tvMeta.setText(meta.toString());
        tvMeta.setTextSize(12);
        tvMeta.setTextColor(Color.parseColor("#475569"));
        card.addView(tvMeta);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(item.title);
        tvTitle.setTextSize(16);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(item.completed ? Color.parseColor("#64748B") : Color.parseColor("#0F172A"));
        tvTitle.setPadding(0, dp(6), 0, dp(4));
        card.addView(tvTitle);

        // شريط توقيت وتكرار التنبيه الخاص بهذه المهمة
        if (!item.completed) {
            TextView tvScheduleBadge = new TextView(this);
            if (item.reminderEnabled) {
                tvScheduleBadge.setText("🔁 " + TaskItem.formatIntervalLabel(item.repeatIntervalHours)
                        + "   •   ⏰ القادم: " + item.getFormattedNextReminder());
                tvScheduleBadge.setTextColor(Color.parseColor("#0F4C81"));
                GradientDrawable schBg = new GradientDrawable();
                schBg.setColor(Color.parseColor("#EFF6FF"));
                schBg.setCornerRadius(dp(8));
                tvScheduleBadge.setBackground(schBg);
            } else {
                tvScheduleBadge.setText("🔕 تنبيه هذه المهمة متوقف مؤقتاً");
                tvScheduleBadge.setTextColor(Color.parseColor("#64748B"));
                GradientDrawable schBg = new GradientDrawable();
                schBg.setColor(Color.parseColor("#F1F5F9"));
                schBg.setCornerRadius(dp(8));
                tvScheduleBadge.setBackground(schBg);
            }
            tvScheduleBadge.setTextSize(12);
            tvScheduleBadge.setTypeface(null, Typeface.BOLD);
            tvScheduleBadge.setPadding(dp(10), dp(6), dp(10), dp(6));
            LinearLayout.LayoutParams schLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            schLp.topMargin = dp(2);
            schLp.bottomMargin = dp(6);
            tvScheduleBadge.setLayoutParams(schLp);
            card.addView(tvScheduleBadge);
        }

        if (item.notes != null && !item.notes.trim().isEmpty()) {
            TextView tvNotes = new TextView(this);
            tvNotes.setText("💡 " + item.notes);
            tvNotes.setTextSize(13);
            tvNotes.setTextColor(Color.parseColor("#334155"));
            tvNotes.setPadding(0, 0, 0, dp(6));
            card.addView(tvNotes);
        }

        if (!item.completed) {
            // الصف الأول من الأزرار: إنجاز + اختيار التكرار (1-12 ساعة) + اختيار التوقيت
            LinearLayout row1 = new LinearLayout(this);
            row1.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams r1Lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            r1Lp.topMargin = dp(4);
            row1.setLayoutParams(r1Lp);

            Button btnDone = makeCardActionBtn("✅ إنجاز", "#15803D", 1f, false);
            btnDone.setOnClickListener(v -> {
                TaskStorage.markCompleted(this, item.id, true);
                refreshUi();
                Toast.makeText(this, "تم إنجاز المهمة وإيقاف تنبيهها!", Toast.LENGTH_SHORT).show();
            });

            Button btnInterval = makeCardActionBtn("🔁 " + TaskItem.formatIntervalLabel(item.repeatIntervalHours), "#0F4C81", 1.15f, true);
            btnInterval.setOnClickListener(v -> showIntervalPickerDialog(item));

            Button btnTime = makeCardActionBtn("🕒 توقيت", "#7C3AED", 0.9f, true);
            btnTime.setOnClickListener(v -> showTaskTimePicker(item));

            row1.addView(btnDone);
            row1.addView(btnInterval);
            row1.addView(btnTime);
            card.addView(row1);

            // الصف الثاني من الأزرار: إيقاف/تشغيل تنبيه المهمة + للغد + تعديل + حذف
            LinearLayout row2 = new LinearLayout(this);
            row2.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams r2Lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            r2Lp.topMargin = dp(6);
            row2.setLayoutParams(r2Lp);

            Button btnToggleBell = makeCardActionBtn(
                    item.reminderEnabled ? "🔕 إيقاف" : "🔔 تفعيل",
                    item.reminderEnabled ? "#475569" : "#0F766E",
                    1f,
                    false
            );
            btnToggleBell.setOnClickListener(v -> {
                item.reminderEnabled = !item.reminderEnabled;
                if (item.reminderEnabled && item.nextReminderAt <= System.currentTimeMillis()) {
                    item.nextReminderAt = TaskItem.computeDefaultNextReminder(item.dueDate, item.repeatIntervalHours);
                }
                TaskStorage.updateTask(this, item);
                refreshUi();
            });

            Button btnSnooze = makeCardActionBtn("⏳ للغد", "#D97706", 0.9f, true);
            btnSnooze.setOnClickListener(v -> {
                TaskStorage.snoozeTaskUntilTomorrow(this, item.id);
                refreshUi();
                Toast.makeText(this, "تم تأجيل المهمة للغد (08:00 ص)", Toast.LENGTH_SHORT).show();
            });

            Button btnEdit = makeCardActionBtn("✏️ تعديل", "#1E40AF", 0.9f, true);
            btnEdit.setOnClickListener(v -> showEditTaskDialog(item));

            Button btnDel = makeCardActionBtn("🗑️", "#B91C1C", 0.55f, true);
            btnDel.setOnClickListener(v -> {
                TaskStorage.deleteTask(this, item.id);
                refreshUi();
            });

            row2.addView(btnToggleBell);
            row2.addView(btnSnooze);
            row2.addView(btnEdit);
            row2.addView(btnDel);
            card.addView(row2);
        } else {
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            actLp.topMargin = dp(6);
            actions.setLayoutParams(actLp);

            Button btnRestore = makeCardActionBtn("↩️ استرجاع للمهام", "#2563EB", 1.5f, false);
            btnRestore.setOnClickListener(v -> {
                TaskStorage.markCompleted(this, item.id, false);
                refreshUi();
            });

            Button btnDel = makeCardActionBtn("🗑️ حذف نهائي", "#B91C1C", 1f, true);
            btnDel.setOnClickListener(v -> {
                TaskStorage.deleteTask(this, item.id);
                refreshUi();
            });

            actions.addView(btnRestore);
            actions.addView(btnDel);
            card.addView(actions);
        }

        return card;
    }

    /**
     * نافذة سريعة لاختيار تكرار التنبيه لهذه المهمة من 1 إلى 12 ساعة (12 خياراً)
     */
    private void showIntervalPickerDialog(final TaskItem item) {
        final String[] options = TaskItem.getIntervalOptions();
        int checkedIndex = TaskItem.clampInterval(item.repeatIntervalHours) - 1;

        new AlertDialog.Builder(this)
                .setTitle("تكرار تنبيه: " + item.title)
                .setSingleChoiceItems(options, checkedIndex, (dialog, which) -> {
                    int chosenHours = which + 1;
                    item.repeatIntervalHours = chosenHours;
                    item.reminderEnabled = true;
                    item.nextReminderAt = TaskItem.computeDefaultNextReminder(item.dueDate, chosenHours);
                    TaskStorage.updateTask(MainActivity.this, item);
                    refreshUi();
                    Toast.makeText(
                            MainActivity.this,
                            "تم الضبط: " + TaskItem.formatIntervalLabel(chosenHours) + " • القادم " + item.getFormattedNextReminder(),
                            Toast.LENGTH_SHORT
                    ).show();
                    dialog.dismiss();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    /**
     * اختيار ساعة ودقيقة التنبيه القادم لهذه المهمة بدقة
     */
    private void showTaskTimePicker(final TaskItem item) {
        final Calendar cal = Calendar.getInstance();
        if (item.nextReminderAt > System.currentTimeMillis()) {
            cal.setTimeInMillis(item.nextReminderAt);
        } else {
            cal.add(Calendar.HOUR_OF_DAY, 1);
            cal.set(Calendar.MINUTE, 0);
        }

        TimePickerDialog picker = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    Calendar chosen = Calendar.getInstance();
                    chosen.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    chosen.set(Calendar.MINUTE, minute);
                    chosen.set(Calendar.SECOND, 0);
                    chosen.set(Calendar.MILLISECOND, 0);
                    if (chosen.getTimeInMillis() <= System.currentTimeMillis()) {
                        chosen.add(Calendar.DAY_OF_YEAR, 1);
                    }
                    item.nextReminderAt = chosen.getTimeInMillis();
                    item.reminderEnabled = true;
                    TaskStorage.updateTask(MainActivity.this, item);
                    refreshUi();
                    Toast.makeText(
                            MainActivity.this,
                            "التنبيه القادم لهذه المهمة: " + item.getFormattedNextReminder()
                                    + " (" + TaskItem.formatIntervalLabel(item.repeatIntervalHours) + ")",
                            Toast.LENGTH_SHORT
                    ).show();
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                false
        );
        picker.setTitle("توقيت التنبيه القادم للمهمة");
        picker.show();
    }

    private void showErrorMessage(String msg) {
        if (msg != null && msg.length() > 75) {
            new AlertDialog.Builder(this)
                    .setTitle("تنبيه من Gemini")
                    .setMessage(msg)
                    .setPositiveButton("حسناً", null)
                    .show();
        } else {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        }
    }

    private void handleTextSubmit() {
        String text = taskInput.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "اكتب مهامك أولاً أو استخدم التسجيل الصوتي", Toast.LENGTH_SHORT).show();
            return;
        }
        setLoading(true);
        int defHours = TaskStorage.getDefaultIntervalHours(this);
        GeminiClient.extractTasksFromText(TaskStorage.getApiKey(this), text, defHours, new GeminiClient.Callback() {
            @Override
            public void onSuccess(List<TaskItem> tasks) {
                setLoading(false);
                if (tasks.isEmpty()) {
                    Toast.makeText(MainActivity.this, "لم يتم العثور على مهام واضحة.", Toast.LENGTH_LONG).show();
                    return;
                }
                TaskStorage.addTasks(MainActivity.this, tasks);
                taskInput.setText("");
                refreshUi();
                Toast.makeText(MainActivity.this, "تمت إضافة وترتيب " + tasks.size() + " مهام!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(String message) {
                setLoading(false);
                showErrorMessage(message);
            }
        });
    }

    private void handleSmartReplan() {
        List<TaskItem> pending = TaskStorage.getPendingTasks(this);
        if (pending.size() < 2) {
            Toast.makeText(this, "تحتاج لمهمتين على الأقل لإعادة الترتيب الذكي.", Toast.LENGTH_SHORT).show();
            return;
        }
        setLoading(true);
        int defHours = TaskStorage.getDefaultIntervalHours(this);
        GeminiClient.replanExistingTasks(TaskStorage.getApiKey(this), pending, defHours, new GeminiClient.Callback() {
            @Override
            public void onSuccess(List<TaskItem> replanned) {
                setLoading(false);
                if (!replanned.isEmpty()) {
                    TaskStorage.replacePendingTasks(MainActivity.this, replanned);
                    refreshUi();
                    Toast.makeText(MainActivity.this, "تمت إعادة ترتيب خطتك بذكاء!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(String message) {
                setLoading(false);
                showErrorMessage(message);
            }
        });
    }

    private void toggleVoiceRecording() {
        if (!isRecording) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                return;
            }
            startRecording();
        } else {
            stopAndSendRecording();
        }
    }

    @SuppressWarnings("deprecation")
    private void startRecording() {
        try {
            currentAudioFile = new File(getCacheDir(), "voice_" + System.currentTimeMillis() + ".m4a");
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setAudioEncodingBitRate(64000);
            mediaRecorder.setAudioSamplingRate(22050);
            mediaRecorder.setOutputFile(currentAudioFile.getAbsolutePath());
            mediaRecorder.prepare();
            mediaRecorder.start();

            isRecording = true;
            btnRecordVoice.setText("⏹ إيقاف وإرسال");
            setButtonColor(btnRecordVoice, "#B91C1C");
            btnProcessText.setEnabled(false);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر بدء التسجيل: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopAndSendRecording() {
        try {
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder = null;
            }
        } catch (Exception ignored) {
        }
        isRecording = false;
        btnRecordVoice.setText("🎤 تسجيل صوتي");
        setButtonColor(btnRecordVoice, "#15803D");
        btnProcessText.setEnabled(true);

        if (currentAudioFile != null && currentAudioFile.exists()) {
            setLoading(true);
            int defHours = TaskStorage.getDefaultIntervalHours(this);
            GeminiClient.extractTasksFromAudio(TaskStorage.getApiKey(this), currentAudioFile, defHours, new GeminiClient.Callback() {
                @Override
                public void onSuccess(List<TaskItem> tasks) {
                    setLoading(false);
                    if (tasks.isEmpty()) {
                        Toast.makeText(MainActivity.this, "لم يتم التعرف على مهام في التسجيل.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    TaskStorage.addTasks(MainActivity.this, tasks);
                    refreshUi();
                    Toast.makeText(MainActivity.this, "تم استخراج وترتيب " + tasks.size() + " مهام من صوتك!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onError(String message) {
                    setLoading(false);
                    showErrorMessage(message);
                }
            });
        }
    }

    private void showEditTaskDialog(final TaskItem existing) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(existing == null ? "إضافة مهمة يدوياً" : "تعديل المهمة وتوقيتها");

        ScrollView scroll = new ScrollView(this);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        form.setPadding(dp(18), dp(10), dp(18), dp(6));

        final EditText etTitle = new EditText(this);
        etTitle.setHint("عنوان المهمة");
        if (existing != null) etTitle.setText(existing.title);

        TextView tvPriLbl = makeFormLabel("الأولوية:");
        final String[] priorities = new String[]{"عالية", "متوسطة", "عادية"};
        final Spinner spPriority = new Spinner(this);
        spPriority.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, priorities));
        if (existing != null) {
            for (int i = 0; i < priorities.length; i++) {
                if (priorities[i].equals(existing.priority)) spPriority.setSelection(i);
            }
        }

        TextView tvCatLbl = makeFormLabel("التصنيف:");
        final String[] categories = new String[]{"دراسة", "بحث", "عمل", "شخصي", "عام"};
        final Spinner spCategory = new Spinner(this);
        spCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
        if (existing != null) {
            for (int i = 0; i < categories.length; i++) {
                if (categories[i].equals(existing.category)) spCategory.setSelection(i);
            }
        }

        TextView tvIntLbl = makeFormLabel("إعادة التنبيه (من ساعة إلى 12 ساعة):");
        final String[] intervalOpts = TaskItem.getIntervalOptions();
        final Spinner spInterval = new Spinner(this);
        spInterval.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, intervalOpts));
        int initInterval = existing != null
                ? TaskItem.clampInterval(existing.repeatIntervalHours)
                : TaskStorage.getDefaultIntervalHours(this);
        spInterval.setSelection(initInterval - 1);

        final long[] chosenNextTime = new long[]{
                existing != null ? existing.nextReminderAt : TaskItem.computeDefaultNextReminder("", initInterval)
        };
        final boolean[] timePickedExplicitly = new boolean[]{false};

        SimpleDateFormat tf = new SimpleDateFormat("hh:mm a", new Locale("ar"));
        final Button btnPickTime = makePillButton("🕒 توقيت أول تنبيه: " + tf.format(new Date(chosenNextTime[0])), "#7C3AED");
        LinearLayout.LayoutParams tpLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        tpLp.topMargin = dp(8);
        btnPickTime.setLayoutParams(tpLp);
        btnPickTime.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(chosenNextTime[0]);
            new TimePickerDialog(MainActivity.this, (view, hourOfDay, minute) -> {
                Calendar picked = Calendar.getInstance();
                picked.set(Calendar.HOUR_OF_DAY, hourOfDay);
                picked.set(Calendar.MINUTE, minute);
                picked.set(Calendar.SECOND, 0);
                picked.set(Calendar.MILLISECOND, 0);
                if (picked.getTimeInMillis() <= System.currentTimeMillis()) {
                    picked.add(Calendar.DAY_OF_YEAR, 1);
                }
                chosenNextTime[0] = picked.getTimeInMillis();
                timePickedExplicitly[0] = true;
                btnPickTime.setText("🕒 توقيت أول تنبيه: " + tf.format(picked.getTime()));
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show();
        });

        final SwitchMaterial swEnable = new SwitchMaterial(this);
        swEnable.setText("تفعيل التنبيه لهذه المهمة");
        swEnable.setChecked(existing == null || existing.reminderEnabled);
        swEnable.setPadding(0, dp(8), 0, dp(4));

        final EditText etDueLabel = new EditText(this);
        etDueLabel.setHint("وصف اليوم (مثلاً: اليوم، غداً)");
        if (existing != null) etDueLabel.setText(existing.dueLabel);

        final EditText etNotes = new EditText(this);
        etNotes.setHint("ملاحظة أو خطوة تنفيذية (اختياري)");
        if (existing != null) etNotes.setText(existing.notes);

        form.addView(etTitle);
        form.addView(tvPriLbl);
        form.addView(spPriority);
        form.addView(tvCatLbl);
        form.addView(spCategory);
        form.addView(tvIntLbl);
        form.addView(spInterval);
        form.addView(btnPickTime);
        form.addView(swEnable);
        form.addView(etDueLabel);
        form.addView(etNotes);
        scroll.addView(form);

        builder.setView(scroll);
        builder.setPositiveButton("حفظ", (d, w) -> {
            String title = etTitle.getText().toString().trim();
            if (title.isEmpty()) return;
            String pri = priorities[spPriority.getSelectedItemPosition()];
            String cat = categories[spCategory.getSelectedItemPosition()];
            int chosenHours = spInterval.getSelectedItemPosition() + 1;
            String lbl = etDueLabel.getText().toString().trim();
            String notes = etNotes.getText().toString().trim();
            boolean enabled = swEnable.isChecked();

            if (existing == null) {
                long nextAt = timePickedExplicitly[0]
                        ? chosenNextTime[0]
                        : TaskItem.computeDefaultNextReminder("", chosenHours);
                List<TaskItem> single = new ArrayList<>();
                single.add(new TaskItem(
                        "t_" + System.currentTimeMillis(),
                        title, cat, pri, "", lbl, notes, 0, false,
                        System.currentTimeMillis(), 0L, 0L,
                        chosenHours, nextAt, enabled
                ));
                TaskStorage.addTasks(this, single);
            } else {
                boolean intervalChanged = existing.repeatIntervalHours != chosenHours;
                existing.title = title;
                existing.priority = pri;
                existing.category = cat;
                existing.repeatIntervalHours = chosenHours;
                existing.reminderEnabled = enabled;
                existing.dueLabel = lbl;
                existing.notes = notes;
                if (timePickedExplicitly[0]) {
                    existing.nextReminderAt = chosenNextTime[0];
                } else if (intervalChanged) {
                    existing.nextReminderAt = TaskItem.computeDefaultNextReminder(existing.dueDate, chosenHours);
                }
                TaskStorage.updateTask(this, existing);
            }
            refreshUi();
        });
        builder.setNegativeButton("إلغاء", null);
        builder.show();
    }

    private TextView makeFormLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(Color.parseColor("#334155"));
        tv.setPadding(0, dp(8), 0, dp(2));
        return tv;
    }

    private void showSettingsDialog(boolean firstRun) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("إعدادات التطبيق والتنبيه");

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(18), dp(12), dp(18), dp(10));

        TextView tvKey = new TextView(this);
        tvKey.setText("مفتاح Gemini API:");
        tvKey.setTypeface(null, Typeface.BOLD);

        final EditText etKey = new EditText(this);
        etKey.setInputType(InputType.TYPE_CLASS_TEXT);
        etKey.setHint("الصق مفتاح Gemini هنا");
        etKey.setText(TaskStorage.getApiKey(this));

        final TextView tvTestStatus = new TextView(this);
        tvTestStatus.setTextSize(12);
        tvTestStatus.setPadding(0, dp(4), 0, dp(6));

        Button btnTestKey = makePillButton("🔍 فحص صلاحية المفتاح والاتصال", "#1E40AF");
        btnTestKey.setOnClickListener(v -> {
            String candidate = etKey.getText().toString().replaceAll("\\s+", "");
            tvTestStatus.setTextColor(Color.parseColor("#475569"));
            tvTestStatus.setText("جاري فحص المفتاح...");
            GeminiClient.resetEndpointCache();
            GeminiClient.testConnection(candidate, (success, message) -> {
                tvTestStatus.setTextColor(Color.parseColor(success ? "#15803D" : "#B91C1C"));
                tvTestStatus.setText((success ? "✅ " : "❌ ") + message);
            });
        });

        TextView tvDefInt = makeFormLabel("فترة التكرار الافتراضية للمهام الجديدة (1-12 ساعة):");
        final Spinner spDefaultInterval = new Spinner(this);
        spDefaultInterval.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, TaskItem.getIntervalOptions()));
        spDefaultInterval.setSelection(TaskStorage.getDefaultIntervalHours(this) - 1);

        final SwitchMaterial swAlarmStream = new SwitchMaterial(this);
        swAlarmStream.setText("استخدام قناة صوت المنبه (تعمل أثناء الصامت والنوم — مدة 1.5 ثانية)");
        swAlarmStream.setChecked(TaskStorage.isUseAlarmStream(this));
        swAlarmStream.setPadding(0, dp(10), 0, dp(6));

        final SwitchMaterial swSeparate = new SwitchMaterial(this);
        swSeparate.setText("إشعار منفصل لكل مهمة عند تزامن أكثر من مهمة");
        swSeparate.setChecked(TaskStorage.isSeparateNotifs(this));
        swSeparate.setPadding(0, dp(6), 0, dp(12));

        Button btnBackup = makePillButton("📋 نسخ احتياطي للمهام (للحافظة)", "#334155");
        btnBackup.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("MahamiBackup", TaskStorage.exportBackupJson(this)));
                Toast.makeText(this, "تم نسخ جميع مهامك إلى الحافظة!", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnRestore = makePillButton("📥 استعادة مهام من الحافظة", "#0F766E");
        LinearLayout.LayoutParams resLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        resLp.topMargin = dp(8);
        btnRestore.setLayoutParams(resLp);
        btnRestore.setOnClickListener(v -> {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence text = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                    int count = TaskStorage.importBackupJson(this, text.toString());
                    refreshUi();
                    Toast.makeText(this, "تمت استعادة " + count + " مهام بنجاح!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "النص في الحافظة ليس نسخة احتياطية صالحة.", Toast.LENGTH_LONG).show();
            }
        });

        box.addView(tvKey);
        box.addView(etKey);
        box.addView(btnTestKey);
        box.addView(tvTestStatus);
        box.addView(tvDefInt);
        box.addView(spDefaultInterval);
        box.addView(swAlarmStream);
        box.addView(swSeparate);
        box.addView(btnBackup);
        box.addView(btnRestore);
        scroll.addView(box);

        builder.setView(scroll);
        builder.setPositiveButton("حفظ الإعدادات", (d, w) -> {
            TaskStorage.setApiKey(this, etKey.getText().toString().replaceAll("\\s+", ""));
            TaskStorage.setDefaultIntervalHours(this, spDefaultInterval.getSelectedItemPosition() + 1);
            TaskStorage.setUseAlarmStream(this, swAlarmStream.isChecked());
            TaskStorage.setSeparateNotifs(this, swSeparate.isChecked());
            refreshUi();
            Toast.makeText(this, "تم حفظ الإعدادات!", Toast.LENGTH_SHORT).show();
        });
        if (!firstRun) {
            builder.setNegativeButton("إغلاق", null);
        }
        builder.setCancelable(!firstRun);
        builder.show();
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                new AlertDialog.Builder(this)
                        .setTitle("إذن المنبه الدقيق")
                        .setMessage("لتشغيل تنبيهات المهام في توقيتها الدقيق حتى أثناء النوم، فعّل إذن (المنبهات والتذكيرات).")
                        .setPositiveButton("تفعيل الآن", (d, w) -> {
                            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                            i.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        })
                        .setNegativeButton("لاحقاً", null)
                        .show();
            }
        }
    }

    private void requestBatteryExemption() {
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnProcessText.setEnabled(!loading);
        btnRecordVoice.setEnabled(!loading);
        btnSmartReplan.setEnabled(!loading);
    }

    private LinearLayout makeRoundedCard(String bgHex, String borderHex) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor(borderHex));
        card.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    private Button makePillButton(String text, String colorHex) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(13);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setAllCaps(false);
        setButtonColor(btn, colorHex);
        return btn;
    }

    private Button makeSmallHeaderBtn(String text, String colorHex) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12);
        btn.setAllCaps(false);
        btn.setPadding(dp(10), dp(4), dp(10), dp(4));
        setButtonColor(btn, colorHex);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(36));
        btn.setLayoutParams(lp);
        return btn;
    }

    private Button makeCardActionBtn(String text, String colorHex, float weight, boolean marginStart) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12);
        btn.setAllCaps(false);
        btn.setPadding(dp(4), 0, dp(4), 0);
        setButtonColor(btn, colorHex);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), weight);
        if (marginStart) lp.setMarginStart(dp(6));
        btn.setLayoutParams(lp);
        return btn;
    }

    private void setButtonColor(Button btn, String colorHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(colorHex));
        bg.setCornerRadius(dp(10));
        btn.setBackground(bg);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startRecording();
        }
    }
}
