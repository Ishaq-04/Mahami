package com.ishaq.mahami;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmScheduler {

    private static final int REQ_NEXT_TASK_ALARM = 2001;
    private static final int REQ_SHOW_APP = 2002;

    public static TaskItem scheduleNextAlarm(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return null;

        Intent receiverIntent = new Intent(context, HourlyAlarmReceiver.class);
        PendingIntent alarmPendingIntent = PendingIntent.getBroadcast(
                context,
                REQ_NEXT_TASK_ALARM,
                receiverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        TaskItem earliest = TaskStorage.ensureFutureScheduleAndGetEarliest(context);
        if (earliest == null) {
            alarmManager.cancel(alarmPendingIntent);
            return null;
        }

        long triggerAt = earliest.nextReminderAt;

        Intent openAppIntent = new Intent(context, MainActivity.class);
        PendingIntent showPendingIntent = PendingIntent.getActivity(
                context,
                REQ_SHOW_APP,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent);
                alarmManager.setAlarmClock(info, alarmPendingIntent);
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, alarmPendingIntent);
            }
        } else {
            AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent);
            alarmManager.setAlarmClock(info, alarmPendingIntent);
        }
        return earliest;
    }
}
